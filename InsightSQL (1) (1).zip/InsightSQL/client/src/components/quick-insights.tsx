import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";

interface QuickInsight {
  topEngagedUsers: Array<{
    name: string;
    email: string;
    avg_engagement: number;
    metrics_count: number;
  }>;
  trendingFeatures: Array<{
    name: string;
    category: string;
    usage_count: number;
    unique_users: number;
  }>;
  growthMetrics: Array<{
    date: string;
    new_users: number;
  }>;
  recentActivity: Array<{
    event_type: string;
    user_name: string;
    feature_name: string;
    timestamp: string;
  }>;
}

export function QuickInsights() {
  const { data: insights, isLoading, error } = useQuery<QuickInsight>({
    queryKey: ['/api/insights'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  if (error) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-red-600">
            <i className="fas fa-exclamation-triangle"></i>
            <span>Insights Error</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            Failed to load insights. Please try again later.
          </p>
        </CardContent>
      </Card>
    );
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        {[1, 2, 3, 4].map(i => (
          <Card key={i}>
            <CardHeader>
              <Skeleton className="h-6 w-48" />
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric'
    });
  };

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const totalNewUsers = insights?.growthMetrics.reduce((sum, metric) => sum + metric.new_users, 0) || 0;

  return (
    <div className="space-y-6" data-testid="quick-insights-container">
      {/* Top Engaged Users */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <i className="fas fa-star text-yellow-500"></i>
            <span>Top Engaged Users</span>
            <Badge variant="secondary" className="ml-auto">Last 30 days</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {insights?.topEngagedUsers && insights.topEngagedUsers.length > 0 ? (
            <div className="space-y-3">
              {insights.topEngagedUsers.slice(0, 5).map((user, index) => (
                <div
                  key={user.email}
                  className="flex items-center justify-between p-3 bg-muted/50 rounded-lg"
                  data-testid={`top-user-${index}`}
                >
                  <div className="flex items-center space-x-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                      index === 0 ? 'bg-yellow-500 text-white' :
                      index === 1 ? 'bg-gray-400 text-white' :
                      index === 2 ? 'bg-orange-400 text-white' :
                      'bg-blue-500 text-white'
                    }`}>
                      {index + 1}
                    </div>
                    <div>
                      <p className="font-medium text-sm">{user.name}</p>
                      <p className="text-xs text-muted-foreground">{user.email}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-sm">
                      {parseFloat(user.avg_engagement).toFixed(1)}/10
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {user.metrics_count} sessions
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-4">
              <i className="fas fa-user-clock text-2xl text-muted-foreground mb-2"></i>
              <p className="text-sm text-muted-foreground">No engagement data available</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Trending Features */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <i className="fas fa-trending-up text-green-500"></i>
            <span>Trending Features</span>
            <Badge variant="secondary" className="ml-auto">Last 7 days</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {insights?.trendingFeatures && insights.trendingFeatures.length > 0 ? (
            <div className="space-y-3">
              {insights.trendingFeatures.slice(0, 5).map((feature, index) => (
                <div
                  key={feature.name}
                  className="flex items-center justify-between p-3 bg-muted/50 rounded-lg"
                  data-testid={`trending-feature-${index}`}
                >
                  <div className="flex items-center space-x-3">
                    <i className="fas fa-fire text-orange-500"></i>
                    <div>
                      <p className="font-medium text-sm">{feature.name}</p>
                      <Badge variant="outline" className="text-xs">
                        {feature.category}
                      </Badge>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-sm">{feature.usage_count} uses</p>
                    <p className="text-xs text-muted-foreground">
                      {feature.unique_users} unique users
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-4">
              <i className="fas fa-chart-line text-2xl text-muted-foreground mb-2"></i>
              <p className="text-sm text-muted-foreground">No trending features data</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Growth Metrics */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <i className="fas fa-chart-area text-blue-500"></i>
            <span>Growth Overview</span>
            <Badge variant="secondary" className="ml-auto">Last 30 days</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {insights?.growthMetrics && insights.growthMetrics.length > 0 ? (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-4 bg-muted/50 rounded-lg">
                  <p className="text-2xl font-bold text-blue-600">{totalNewUsers}</p>
                  <p className="text-xs text-muted-foreground">Total New Users</p>
                </div>
                <div className="text-center p-4 bg-muted/50 rounded-lg">
                  <p className="text-2xl font-bold text-green-600">
                    {Math.round(totalNewUsers / Math.max(insights.growthMetrics.length, 1))}
                  </p>
                  <p className="text-xs text-muted-foreground">Avg. Daily Signups</p>
                </div>
              </div>
              
              <div className="space-y-2">
                <p className="text-sm font-medium">Recent Daily Signups</p>
                <div className="flex justify-between text-xs text-muted-foreground">
                  {insights.growthMetrics.slice(0, 7).map((metric, index) => (
                    <div key={metric.date} className="text-center" data-testid={`growth-metric-${index}`}>
                      <div className="w-8 h-16 bg-muted rounded-sm mb-1 relative">
                        <div 
                          className="bg-blue-500 rounded-sm absolute bottom-0 w-full"
                          style={{ 
                            height: `${Math.max(10, (metric.new_users / Math.max(...insights.growthMetrics.map(m => m.new_users))) * 100)}%` 
                          }}
                        ></div>
                      </div>
                      <p>{formatDate(metric.date)}</p>
                      <p className="font-medium">{metric.new_users}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-4">
              <i className="fas fa-chart-bar text-2xl text-muted-foreground mb-2"></i>
              <p className="text-sm text-muted-foreground">No growth data available</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <i className="fas fa-clock text-purple-500"></i>
            <span>Recent Activity</span>
            <Badge variant="secondary" className="ml-auto">Live</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {insights?.recentActivity && insights.recentActivity.length > 0 ? (
            <div className="space-y-3">
              {insights.recentActivity.slice(0, 8).map((activity, index) => (
                <div
                  key={index}
                  className="flex items-center space-x-3 p-2 hover:bg-muted/50 rounded-lg transition-colors"
                  data-testid={`recent-activity-${index}`}
                >
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <div className="flex-1">
                    <p className="text-sm">
                      <span className="font-medium">{activity.user_name}</span>
                      <span className="text-muted-foreground"> {activity.event_type.replace(/_/g, ' ')} </span>
                      {activity.feature_name && (
                        <span className="text-blue-600">{activity.feature_name}</span>
                      )}
                    </p>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {formatTime(activity.timestamp)}
                  </p>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-4">
              <i className="fas fa-history text-2xl text-muted-foreground mb-2"></i>
              <p className="text-sm text-muted-foreground">No recent activity</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}