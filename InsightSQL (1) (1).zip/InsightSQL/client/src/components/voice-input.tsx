import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

interface VoiceInputProps {
  onVoiceResult: (transcript: string) => void;
  isDisabled?: boolean;
}

export function VoiceInput({ onVoiceResult, isDisabled = false }: VoiceInputProps) {
  const [isListening, setIsListening] = useState(false);
  const [isSupported, setIsSupported] = useState(false);
  const [finalTranscript, setFinalTranscript] = useState("");
  const [interimTranscript, setInterimTranscript] = useState("");
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    // Check if Speech Recognition is supported
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    
    if (SpeechRecognition) {
      setIsSupported(true);
      
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';
      recognition.maxAlternatives = 1;

      recognition.onstart = () => {
        setIsListening(true);
        setFinalTranscript("");
        setInterimTranscript("");
      };

      recognition.onresult = (event: SpeechRecognitionEvent) => {
        let interim = "";
        let final = "";

        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;
          
          if (event.results[i].isFinal) {
            final += transcript;
          } else {
            interim += transcript;
          }
        }

        setInterimTranscript(interim);
        if (final) {
          setFinalTranscript(prev => prev + final);
        }
      };

      recognition.onend = () => {
        setIsListening(false);
        const fullTranscript = finalTranscript + interimTranscript;
        if (fullTranscript.trim()) {
          onVoiceResult(fullTranscript.trim());
          toast({
            title: "Voice Input Received",
            description: "Converting your speech to query...",
          });
        }
        setInterimTranscript("");
      };

      recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
        setIsListening(false);
        setInterimTranscript("");
        
        let errorMessage = "Voice recognition failed";
        switch (event.error) {
          case 'no-speech':
            errorMessage = "No speech detected. Please try again.";
            break;
          case 'audio-capture':
            errorMessage = "Audio capture failed. Check your microphone.";
            break;
          case 'not-allowed':
            errorMessage = "Microphone access denied. Please allow microphone access.";
            break;
          case 'network':
            errorMessage = "Network error occurred during voice recognition.";
            break;
          default:
            errorMessage = `Voice recognition error: ${event.error}`;
        }
        
        toast({
          title: "Voice Input Error",
          description: errorMessage,
          variant: "destructive",
        });
      };

      recognitionRef.current = recognition;
    } else {
      setIsSupported(false);
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort();
      }
    };
  }, [onVoiceResult, toast, finalTranscript, interimTranscript]);

  const startListening = () => {
    if (recognitionRef.current && !isListening) {
      try {
        recognitionRef.current.start();
      } catch (error) {
        toast({
          title: "Voice Input Error",
          description: "Failed to start voice recognition",
          variant: "destructive",
        });
      }
    }
  };

  const stopListening = () => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop();
    }
  };

  if (!isSupported) {
    return (
      <Button 
        variant="outline" 
        size="sm" 
        disabled 
        className="opacity-50"
        data-testid="voice-input-unsupported"
      >
        <i className="fas fa-microphone-slash mr-2"></i>
        Voice Not Supported
      </Button>
    );
  }

  return (
    <div className="flex items-center space-x-2">
      <Button
        variant={isListening ? "destructive" : "outline"}
        size="sm"
        onClick={isListening ? stopListening : startListening}
        disabled={isDisabled}
        className={`transition-all duration-200 ${
          isListening 
            ? "animate-pulse bg-red-500 hover:bg-red-600 text-white" 
            : "hover:bg-accent"
        }`}
        data-testid="voice-input-button"
      >
        <i className={`fas ${isListening ? "fa-stop" : "fa-microphone"} mr-2`}></i>
        {isListening ? "Stop" : "Voice"}
      </Button>
      
      {(isListening || interimTranscript) && (
        <div className="flex items-center space-x-2 text-sm">
          {isListening && (
            <div className="flex space-x-1">
              <div className="w-2 h-2 bg-red-500 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
              <div className="w-2 h-2 bg-red-500 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
              <div className="w-2 h-2 bg-red-500 rounded-full animate-bounce"></div>
            </div>
          )}
          {interimTranscript && (
            <span className="text-muted-foreground italic" data-testid="voice-interim-transcript">
              "{interimTranscript}"
            </span>
          )}
        </div>
      )}
    </div>
  );
}

// Extend the Window interface to include speech recognition
declare global {
  interface Window {
    SpeechRecognition: typeof SpeechRecognition;
    webkitSpeechRecognition: typeof SpeechRecognition;
  }
}