import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface ExportOptionsProps {
  data: any[];
  queryInfo: {
    question: string;
    sql: string;
    executionTime: number;
    resultCount: number;
  };
}

export function ExportOptions({ data, queryInfo }: ExportOptionsProps) {
  const [isExporting, setIsExporting] = useState(false);
  const [isSharing, setIsSharing] = useState(false);
  const [shareOptions, setShareOptions] = useState({
    isPublic: false,
    expiresIn: "24"
  });
  const [shareResult, setShareResult] = useState<{ shareUrl: string; shareToken: string } | null>(null);
  const { toast } = useToast();

  const handleExport = async (format: string) => {
    if (!data || data.length === 0) {
      toast({
        title: "Export Error",
        description: "No data available to export",
        variant: "destructive",
      });
      return;
    }

    setIsExporting(true);
    try {
      const filename = `analytics_export_${new Date().toISOString().split('T')[0]}`;
      
      if (format === "csv") {
        const response = await apiRequest("POST", "/api/queries/export", {
          format,
          data,
          filename,
          queryInfo
        });

        if (response.ok) {
          const blob = await response.blob();
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `${filename}.csv`;
          document.body.appendChild(a);
          a.click();
          window.URL.revokeObjectURL(url);
          document.body.removeChild(a);

          toast({
            title: "Export Successful",
            description: `Data exported as ${format.toUpperCase()}`,
          });
        }
      } else if (format === "json") {
        // Client-side JSON export
        const exportData = {
          metadata: {
            exportDate: new Date().toISOString(),
            query: queryInfo.question,
            sql: queryInfo.sql,
            executionTime: queryInfo.executionTime,
            resultCount: queryInfo.resultCount
          },
          data: data
        };

        const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${filename}.json`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);

        toast({
          title: "Export Successful",
          description: "Data exported as JSON",
        });
      }
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Failed to export data. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsExporting(false);
    }
  };

  const handleCreateShareableLink = async () => {
    setIsSharing(true);
    try {
      // For now, we'll create a mock query ID. In a real app, this would come from the saved query
      const mockQueryId = "query_" + Date.now();
      
      const response = await apiRequest("POST", `/api/queries/${mockQueryId}/share`, shareOptions);
      const result = await response.json();
      
      setShareResult(result);
      
      // Copy to clipboard
      await navigator.clipboard.writeText(result.shareUrl);
      
      toast({
        title: "Shareable Link Created",
        description: "Link copied to clipboard",
      });
    } catch (error) {
      toast({
        title: "Sharing Failed",
        description: "Failed to create shareable link",
        variant: "destructive",
      });
    } finally {
      setIsSharing(false);
    }
  };

  const generateEmbedCode = () => {
    const embedCode = `<!-- DataInsight Pro Embedded Widget -->
<iframe 
  src="${window.location.origin}/embed/query?q=${encodeURIComponent(queryInfo.question)}"
  width="100%" 
  height="400"
  frameborder="0"
  style="border: 1px solid #e5e7eb; border-radius: 8px;">
</iframe>`;

    navigator.clipboard.writeText(embedCode);
    toast({
      title: "Embed Code Copied",
      description: "Widget embed code copied to clipboard",
    });
  };

  const hasData = data && data.length > 0;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <i className="fas fa-share-alt text-blue-500"></i>
          <span>Export & Share</span>
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Export data or create shareable links and embeds
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Export Section */}
        <div className="space-y-3">
          <h4 className="font-medium text-sm">Export Data</h4>
          <div className="grid grid-cols-2 gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleExport("csv")}
              disabled={!hasData || isExporting}
              className="justify-start"
              data-testid="export-csv"
            >
              <i className="fas fa-file-csv mr-2 text-green-600"></i>
              {isExporting ? "Exporting..." : "CSV"}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleExport("json")}
              disabled={!hasData || isExporting}
              className="justify-start"
              data-testid="export-json"
            >
              <i className="fas fa-file-code mr-2 text-blue-600"></i>
              JSON
            </Button>
          </div>
        </div>

        {/* Share Section */}
        <div className="space-y-3">
          <h4 className="font-medium text-sm">Share & Embed</h4>
          
          <Dialog>
            <DialogTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                className="w-full justify-start"
                disabled={!hasData}
                data-testid="create-share-link"
              >
                <i className="fas fa-link mr-2 text-purple-600"></i>
                Create Shareable Link
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create Shareable Link</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="public-share" className="text-sm">
                    Make publicly accessible
                  </Label>
                  <Switch
                    id="public-share"
                    checked={shareOptions.isPublic}
                    onCheckedChange={(checked) => 
                      setShareOptions(prev => ({ ...prev, isPublic: checked }))
                    }
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="expires-in" className="text-sm">
                    Link expires in
                  </Label>
                  <Select
                    value={shareOptions.expiresIn}
                    onValueChange={(value) => 
                      setShareOptions(prev => ({ ...prev, expiresIn: value }))
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1 hour</SelectItem>
                      <SelectItem value="24">24 hours</SelectItem>
                      <SelectItem value="168">1 week</SelectItem>
                      <SelectItem value="720">1 month</SelectItem>
                      <SelectItem value="never">Never</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {shareResult && (
                  <div className="space-y-2">
                    <Label className="text-sm">Shareable URL</Label>
                    <div className="flex items-center space-x-2">
                      <Input
                        value={shareResult.shareUrl}
                        readOnly
                        className="text-xs"
                      />
                      <Button
                        size="sm"
                        onClick={() => navigator.clipboard.writeText(shareResult.shareUrl)}
                      >
                        <i className="fas fa-copy"></i>
                      </Button>
                    </div>
                  </div>
                )}

                <Button
                  onClick={handleCreateShareableLink}
                  disabled={isSharing}
                  className="w-full"
                  data-testid="generate-share-link"
                >
                  {isSharing ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i>
                      Creating Link...
                    </>
                  ) : (
                    <>
                      <i className="fas fa-share mr-2"></i>
                      Generate Link
                    </>
                  )}
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          <Button
            variant="outline"
            size="sm"
            onClick={generateEmbedCode}
            disabled={!hasData}
            className="w-full justify-start"
            data-testid="generate-embed"
          >
            <i className="fas fa-code mr-2 text-orange-600"></i>
            Generate Embed Code
          </Button>
        </div>

        {/* Quick Actions */}
        <div className="space-y-3">
          <h4 className="font-medium text-sm">Quick Actions</h4>
          <div className="space-y-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => window.print()}
              className="w-full justify-start text-muted-foreground hover:text-foreground"
              data-testid="print-results"
            >
              <i className="fas fa-print mr-2"></i>
              Print Results
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                const url = new URL(window.location.href);
                url.searchParams.set('q', queryInfo.question);
                navigator.clipboard.writeText(url.toString());
                toast({
                  title: "URL Copied",
                  description: "Page URL with query copied to clipboard"
                });
              }}
              className="w-full justify-start text-muted-foreground hover:text-foreground"
              data-testid="copy-url"
            >
              <i className="fas fa-external-link-alt mr-2"></i>
              Copy Page URL
            </Button>
          </div>
        </div>

        {!hasData && (
          <div className="text-center py-4 text-muted-foreground">
            <i className="fas fa-database text-2xl mb-2 opacity-50"></i>
            <p className="text-sm">Run a query to enable export options</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}