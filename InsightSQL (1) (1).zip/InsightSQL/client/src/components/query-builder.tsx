import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { VoiceInput } from "@/components/voice-input";
import type { QueryState } from "@/pages/dashboard";

interface QueryBuilderProps {
  queryState: QueryState;
  setQueryState: (state: QueryState | ((prev: QueryState) => QueryState)) => void;
  isLoading: boolean;
  setIsLoading: (loading: boolean) => void;
}

const suggestedQuestions = [
  "User growth by month",
  "Feature adoption rates",
  "Churn analysis by segment",
  "Revenue per customer",
];

export function QueryBuilder({ 
  queryState, 
  setQueryState, 
  isLoading, 
  setIsLoading 
}: QueryBuilderProps) {
  const { toast } = useToast();
  const [generatedSQL, setGeneratedSQL] = useState("");
  const [sqlExplanation, setSqlExplanation] = useState("");

  const handleGenerateSQL = async () => {
    if (!queryState.question.trim()) {
      toast({
        title: "Error",
        description: "Please enter a question first",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      const response = await apiRequest("POST", "/api/queries/generate", {
        question: queryState.question,
      });
      
      const data = await response.json();
      
      setGeneratedSQL(data.sql);
      setSqlExplanation(data.explanation);
      
      setQueryState(prev => ({
        ...prev,
        sql: data.sql,
        explanation: data.explanation,
      }));

      toast({
        title: "SQL Generated",
        description: "Query has been generated successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate SQL query",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleExecuteQuery = async () => {
    if (!queryState.sql.trim()) {
      toast({
        title: "Error",
        description: "No SQL query to execute",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      const response = await apiRequest("POST", "/api/queries/execute", {
        sqlQuery: queryState.sql,
        question: queryState.question,
      });
      
      const data = await response.json();
      
      setQueryState(prev => ({
        ...prev,
        results: data.results,
        executionTime: data.executionTime,
        resultCount: data.resultCount,
      }));

      toast({
        title: "Query Executed",
        description: `Retrieved ${data.resultCount} results in ${data.executionTime.toFixed(3)}s`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to execute SQL query",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    setQueryState(prev => ({ ...prev, question: suggestion }));
  };

  return (
    <div className="bg-card border-b border-border p-6">
      <div className="max-w-4xl">
        <label className="block text-sm font-medium text-foreground mb-3">
          Ask a question about your data
        </label>
        <div className="relative">
          <Textarea
            className="w-full px-4 py-3 pr-12 border border-border rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent text-foreground placeholder-muted-foreground bg-background"
            rows={3}
            placeholder="e.g., Show me the top 10 features by user engagement this month, or Which user segments have the highest retention rates?"
            value={queryState.question}
            onChange={(e) => setQueryState(prev => ({ ...prev, question: e.target.value }))}
            data-testid="input-question"
          />
          <div className="absolute right-3 bottom-3 flex items-center space-x-2">
            <VoiceInput 
              onVoiceResult={(transcript) => 
                setQueryState(prev => ({ ...prev, question: transcript }))
              }
              isDisabled={isLoading}
            />
            <Button
              className="px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-colors"
              onClick={handleGenerateSQL}
              disabled={isLoading || !queryState.question.trim()}
              data-testid="button-generate-sql"
            >
              {isLoading ? (
                <i className="fas fa-spinner fa-spin"></i>
              ) : (
                <i className="fas fa-arrow-right"></i>
              )}
            </Button>
          </div>
        </div>
        
        {/* Quick Suggestions */}
        <div className="mt-4">
          <p className="text-xs font-medium text-muted-foreground mb-2">Suggested questions:</p>
          <div className="flex flex-wrap gap-2">
            {suggestedQuestions.map((suggestion) => (
              <Button
                key={suggestion}
                variant="outline"
                size="sm"
                className="px-3 py-1 text-xs bg-muted text-muted-foreground rounded-full hover:bg-accent hover:text-accent-foreground transition-colors"
                onClick={() => handleSuggestionClick(suggestion)}
                data-testid={`suggestion-${suggestion.toLowerCase().replace(/\s+/g, "-")}`}
              >
                {suggestion}
              </Button>
            ))}
          </div>
        </div>

        {/* Generated SQL Display */}
        {generatedSQL && (
          <div className="mt-6 bg-card rounded-lg border border-border">
            <div className="flex items-center justify-between p-4 border-b border-border">
              <h3 className="font-semibold text-foreground">Generated SQL Query</h3>
              <div className="flex items-center space-x-2">
                <Button
                  variant="ghost"
                  size="sm"
                  className="p-2 text-muted-foreground hover:text-foreground hover:bg-muted rounded-md transition-colors"
                  title="Copy to clipboard"
                  onClick={() => navigator.clipboard.writeText(generatedSQL)}
                  data-testid="button-copy-sql"
                >
                  <i className="fas fa-copy text-sm"></i>
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="p-2 text-muted-foreground hover:text-foreground hover:bg-muted rounded-md transition-colors"
                  title="Edit query"
                  data-testid="button-edit-sql"
                >
                  <i className="fas fa-edit text-sm"></i>
                </Button>
              </div>
            </div>
            <div className="p-4">
              <pre className="text-sm text-foreground bg-muted p-4 rounded-md overflow-x-auto">
                <code data-testid="text-sql-query">{generatedSQL}</code>
              </pre>
              {sqlExplanation && (
                <p className="text-sm text-muted-foreground mt-3" data-testid="text-sql-explanation">
                  {sqlExplanation}
                </p>
              )}
            </div>
            <div className="flex items-center justify-between p-4 bg-muted border-t border-border">
              <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                {queryState.executionTime > 0 && (
                  <>
                    <span>
                      <i className="fas fa-clock mr-1"></i>
                      Query time: <span data-testid="text-execution-time">{queryState.executionTime.toFixed(3)}s</span>
                    </span>
                    <span>
                      <i className="fas fa-database mr-1"></i>
                      Rows: <span data-testid="text-result-count">{queryState.resultCount}</span>
                    </span>
                  </>
                )}
              </div>
              <Button
                className="px-4 py-2 bg-primary text-primary-foreground text-sm font-medium rounded-md hover:bg-primary/90 transition-colors"
                onClick={handleExecuteQuery}
                disabled={isLoading || !generatedSQL}
                data-testid="button-execute-query"
              >
                <i className="fas fa-play mr-2"></i>
                Execute Query
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
