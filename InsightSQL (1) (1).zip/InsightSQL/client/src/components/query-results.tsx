import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { ExportOptions } from "@/components/export-options";
import type { QueryState } from "@/pages/dashboard";

interface QueryResultsProps {
  queryState: QueryState;
  isLoading: boolean;
}

export function QueryResults({ queryState, isLoading }: QueryResultsProps) {
  const [viewMode, setViewMode] = useState<"table" | "chart">("table");
  const [sortColumn, setSortColumn] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc");

  const handleSort = (column: string) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortColumn(column);
      setSortDirection("asc");
    }
  };

  const getSortedResults = () => {
    if (!sortColumn || !queryState.results.length) return queryState.results;

    return [...queryState.results].sort((a, b) => {
      const aVal = a[sortColumn];
      const bVal = b[sortColumn];

      if (typeof aVal === "number" && typeof bVal === "number") {
        return sortDirection === "asc" ? aVal - bVal : bVal - aVal;
      }

      const aStr = String(aVal || "").toLowerCase();
      const bStr = String(bVal || "").toLowerCase();
      
      if (sortDirection === "asc") {
        return aStr.localeCompare(bStr);
      } else {
        return bStr.localeCompare(aStr);
      }
    });
  };

  const getSortIcon = (column: string) => {
    if (sortColumn !== column) return "fas fa-sort";
    return sortDirection === "asc" ? "fas fa-sort-up" : "fas fa-sort-down";
  };

  const formatCellValue = (value: any) => {
    if (value === null || value === undefined) return "";
    if (typeof value === "number") {
      return value.toLocaleString();
    }
    if (typeof value === "boolean") {
      return value ? "Yes" : "No";
    }
    return String(value);
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-48" />
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-3/4" />
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!queryState.results.length && queryState.sql) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Query Results</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <i className="fas fa-database text-4xl text-muted-foreground mb-4"></i>
            <p className="text-lg font-medium text-foreground mb-2">No results found</p>
            <p className="text-muted-foreground">Your query returned no data.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!queryState.results.length) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Query Results</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <i className="fas fa-search text-4xl text-muted-foreground mb-4"></i>
            <p className="text-lg font-medium text-foreground mb-2">Run a query to see results</p>
            <p className="text-muted-foreground">Enter a question and generate SQL to get started.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const columns = Object.keys(queryState.results[0] || {});
  const sortedResults = getSortedResults();

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Query Results</CardTitle>
          <div className="flex items-center space-x-2">
            <Button
              variant={viewMode === "table" ? "default" : "outline"}
              size="sm"
              onClick={() => setViewMode("table")}
              data-testid="button-view-table"
            >
              <i className="fas fa-table mr-1"></i>Table
            </Button>
            <Button
              variant={viewMode === "chart" ? "default" : "outline"}
              size="sm"
              onClick={() => setViewMode("chart")}
              data-testid="button-view-chart"
            >
              <i className="fas fa-chart-bar mr-1"></i>Chart
            </Button>
            <Button variant="outline" size="sm" data-testid="button-export">
              <i className="fas fa-download mr-1"></i>Export
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        {viewMode === "table" ? (
          <>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader className="bg-muted">
                  <TableRow>
                    {columns.map((column) => (
                      <TableHead
                        key={column}
                        className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider cursor-pointer hover:text-foreground"
                        onClick={() => handleSort(column)}
                        data-testid={`column-header-${column}`}
                      >
                        {column.replace(/_/g, " ")}
                        <i className={`${getSortIcon(column)} ml-1`}></i>
                      </TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody className="divide-y divide-border">
                  {sortedResults.map((row, index) => (
                    <TableRow
                      key={index}
                      className="hover:bg-muted/50 transition-colors"
                      data-testid={`result-row-${index}`}
                    >
                      {columns.map((column) => (
                        <TableCell
                          key={column}
                          className="px-4 py-3 text-sm text-foreground"
                          data-testid={`cell-${column}-${index}`}
                        >
                          {formatCellValue(row[column])}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            <div className="flex items-center justify-between p-4 border-t border-border text-sm text-muted-foreground">
              <span data-testid="text-results-summary">
                Showing {queryState.resultCount} of {queryState.resultCount} results
              </span>
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  disabled
                  data-testid="button-previous"
                >
                  Previous
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  disabled
                  data-testid="button-next"
                >
                  Next
                </Button>
              </div>
            </div>
          </>
        ) : (
          <div className="p-8 text-center">
            <i className="fas fa-chart-bar text-4xl text-muted-foreground mb-4"></i>
            <p className="text-lg font-medium text-foreground mb-2">Chart View</p>
            <p className="text-muted-foreground">Chart visualization coming soon.</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
