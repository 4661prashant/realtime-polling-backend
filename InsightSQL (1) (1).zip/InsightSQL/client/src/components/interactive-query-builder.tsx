import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { QueryState } from "@/pages/dashboard";

interface QueryCondition {
  id: string;
  table: string;
  column: string;
  operator: string;
  value: string;
  connector: 'AND' | 'OR';
}

interface InteractiveQueryBuilderProps {
  onQueryGenerated: (queryState: QueryState) => void;
}

export function InteractiveQueryBuilder({ onQueryGenerated }: InteractiveQueryBuilderProps) {
  const [selectedTables, setSelectedTables] = useState<string[]>([]);
  const [selectedColumns, setSelectedColumns] = useState<string[]>([]);
  const [conditions, setConditions] = useState<QueryCondition[]>([]);
  const [groupByColumns, setGroupByColumns] = useState<string[]>([]);
  const [orderByColumn, setOrderByColumn] = useState<string>("");
  const [orderDirection, setOrderDirection] = useState<"ASC" | "DESC">("ASC");
  const [limitValue, setLimitValue] = useState<string>("100");
  const [isGenerating, setIsGenerating] = useState(false);
  const { toast } = useToast();

  // Available database tables and their columns
  const tableSchema = {
    users: ["id", "name", "email", "plan", "signup_date", "status"],
    features: ["id", "name", "description", "category", "is_active", "created_at"],
    user_features: ["id", "user_id", "feature_id", "first_used", "last_used", "usage_count"],
    user_metrics: ["id", "user_id", "date", "engagement_score", "session_duration", "actions_count"],
    events: ["id", "user_id", "feature_id", "event_type", "event_data", "timestamp"]
  };

  const operators = [
    { value: "=", label: "equals" },
    { value: "!=", label: "not equals" },
    { value: ">", label: "greater than" },
    { value: ">=", label: "greater than or equal" },
    { value: "<", label: "less than" },
    { value: "<=", label: "less than or equal" },
    { value: "LIKE", label: "contains" },
    { value: "IN", label: "in list" },
    { value: "IS NULL", label: "is null" },
    { value: "IS NOT NULL", label: "is not null" }
  ];

  const addCondition = () => {
    const newCondition: QueryCondition = {
      id: `condition_${Date.now()}`,
      table: Object.keys(tableSchema)[0],
      column: tableSchema[Object.keys(tableSchema)[0] as keyof typeof tableSchema][0],
      operator: "=",
      value: "",
      connector: "AND"
    };
    setConditions(prev => [...prev, newCondition]);
  };

  const updateCondition = (id: string, field: keyof QueryCondition, value: string) => {
    setConditions(prev => prev.map(condition => 
      condition.id === id ? { ...condition, [field]: value } : condition
    ));
  };

  const removeCondition = (id: string) => {
    setConditions(prev => prev.filter(condition => condition.id !== id));
  };

  const generateSQL = () => {
    if (selectedTables.length === 0) {
      toast({
        title: "Error",
        description: "Please select at least one table",
        variant: "destructive",
      });
      return;
    }

    let sql = "SELECT ";
    
    // Columns
    if (selectedColumns.length === 0) {
      sql += "*";
    } else {
      sql += selectedColumns.join(", ");
    }
    
    // FROM clause
    sql += `\nFROM ${selectedTables[0]}`;
    
    // JOINs for multiple tables
    if (selectedTables.length > 1) {
      for (let i = 1; i < selectedTables.length; i++) {
        const table = selectedTables[i];
        if (table === "user_features" && selectedTables.includes("users")) {
          sql += `\nJOIN ${table} ON users.id = ${table}.user_id`;
        } else if (table === "user_features" && selectedTables.includes("features")) {
          sql += `\nJOIN ${table} ON features.id = ${table}.feature_id`;
        } else if (table === "user_metrics" && selectedTables.includes("users")) {
          sql += `\nJOIN ${table} ON users.id = ${table}.user_id`;
        } else if (table === "events" && selectedTables.includes("users")) {
          sql += `\nJOIN ${table} ON users.id = ${table}.user_id`;
        } else if (table === "events" && selectedTables.includes("features")) {
          sql += `\nJOIN ${table} ON features.id = ${table}.feature_id`;
        } else {
          sql += `\nJOIN ${table} ON ${selectedTables[0]}.id = ${table}.${selectedTables[0]}_id`;
        }
      }
    }
    
    // WHERE clause
    if (conditions.length > 0) {
      sql += "\nWHERE ";
      conditions.forEach((condition, index) => {
        if (index > 0) {
          sql += ` ${condition.connector} `;
        }
        
        let conditionSql = `${condition.table}.${condition.column} ${condition.operator}`;
        
        if (!["IS NULL", "IS NOT NULL"].includes(condition.operator)) {
          if (condition.operator === "LIKE") {
            conditionSql += ` '%${condition.value}%'`;
          } else if (condition.operator === "IN") {
            conditionSql += ` (${condition.value})`;
          } else {
            conditionSql += ` '${condition.value}'`;
          }
        }
        
        sql += conditionSql;
      });
    }
    
    // GROUP BY
    if (groupByColumns.length > 0) {
      sql += `\nGROUP BY ${groupByColumns.join(", ")}`;
    }
    
    // ORDER BY
    if (orderByColumn) {
      sql += `\nORDER BY ${orderByColumn} ${orderDirection}`;
    }
    
    // LIMIT
    if (limitValue && parseInt(limitValue) > 0) {
      sql += `\nLIMIT ${limitValue}`;
    }
    
    return sql;
  };

  const handleGenerateAndExecute = async () => {
    const sql = generateSQL();
    if (!sql) return;

    setIsGenerating(true);
    try {
      const response = await apiRequest("POST", "/api/queries/execute", {
        sqlQuery: sql,
        question: "Visual query builder result"
      });
      
      const data = await response.json();
      
      onQueryGenerated({
        question: "Visual query builder result",
        sql: sql,
        results: data.results,
        executionTime: data.executionTime,
        resultCount: data.resultCount,
        explanation: "Query generated using visual query builder"
      });

      toast({
        title: "Query Executed",
        description: `Retrieved ${data.resultCount} results`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to execute query",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <i className="fas fa-puzzle-piece text-purple-500"></i>
          <span>Visual Query Builder</span>
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Build queries visually by selecting tables, columns, and conditions
        </p>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Table Selection */}
        <div className="space-y-3">
          <h4 className="font-medium text-sm">Select Tables</h4>
          <div className="flex flex-wrap gap-2">
            {Object.keys(tableSchema).map(table => (
              <Button
                key={table}
                variant={selectedTables.includes(table) ? "default" : "outline"}
                size="sm"
                onClick={() => {
                  if (selectedTables.includes(table)) {
                    setSelectedTables(prev => prev.filter(t => t !== table));
                  } else {
                    setSelectedTables(prev => [...prev, table]);
                  }
                }}
                data-testid={`table-${table}`}
              >
                {table.replace(/_/g, ' ')}
              </Button>
            ))}
          </div>
        </div>

        {/* Column Selection */}
        {selectedTables.length > 0 && (
          <div className="space-y-3">
            <h4 className="font-medium text-sm">Select Columns</h4>
            <div className="grid grid-cols-2 gap-2">
              {selectedTables.flatMap(table => 
                tableSchema[table as keyof typeof tableSchema].map(column => (
                  <Button
                    key={`${table}.${column}`}
                    variant={selectedColumns.includes(`${table}.${column}`) ? "default" : "outline"}
                    size="sm"
                    onClick={() => {
                      const fullColumn = `${table}.${column}`;
                      if (selectedColumns.includes(fullColumn)) {
                        setSelectedColumns(prev => prev.filter(c => c !== fullColumn));
                      } else {
                        setSelectedColumns(prev => [...prev, fullColumn]);
                      }
                    }}
                    className="text-xs justify-start"
                    data-testid={`column-${table}-${column}`}
                  >
                    {table}.{column}
                  </Button>
                ))
              )}
            </div>
            {selectedColumns.length === 0 && (
              <p className="text-xs text-muted-foreground">No columns selected (will use SELECT *)</p>
            )}
          </div>
        )}

        {/* Conditions */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="font-medium text-sm">Conditions</h4>
            <Button 
              size="sm" 
              variant="outline" 
              onClick={addCondition}
              data-testid="add-condition"
            >
              <i className="fas fa-plus mr-1"></i>
              Add Condition
            </Button>
          </div>
          
          {conditions.map((condition, index) => (
            <div key={condition.id} className="flex items-center space-x-2 p-3 border border-border rounded-lg">
              {index > 0 && (
                <Select
                  value={condition.connector}
                  onValueChange={(value: 'AND' | 'OR') => updateCondition(condition.id, 'connector', value)}
                >
                  <SelectTrigger className="w-16">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="AND">AND</SelectItem>
                    <SelectItem value="OR">OR</SelectItem>
                  </SelectContent>
                </Select>
              )}
              
              <Select
                value={condition.table}
                onValueChange={(value) => updateCondition(condition.id, 'table', value)}
              >
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {selectedTables.map(table => (
                    <SelectItem key={table} value={table}>{table}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Select
                value={condition.column}
                onValueChange={(value) => updateCondition(condition.id, 'column', value)}
              >
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {tableSchema[condition.table as keyof typeof tableSchema]?.map(column => (
                    <SelectItem key={column} value={column}>{column}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Select
                value={condition.operator}
                onValueChange={(value) => updateCondition(condition.id, 'operator', value)}
              >
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {operators.map(op => (
                    <SelectItem key={op.value} value={op.value}>{op.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              {!["IS NULL", "IS NOT NULL"].includes(condition.operator) && (
                <Input
                  placeholder="Value"
                  value={condition.value}
                  onChange={(e) => updateCondition(condition.id, 'value', e.target.value)}
                  className="w-32"
                />
              )}
              
              <Button
                size="sm"
                variant="ghost"
                onClick={() => removeCondition(condition.id)}
                className="text-red-600 hover:text-red-700"
              >
                <i className="fas fa-trash"></i>
              </Button>
            </div>
          ))}
        </div>

        {/* Additional Options */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <h4 className="font-medium text-sm">Order By</h4>
            <div className="flex space-x-2">
              <Select value={orderByColumn} onValueChange={setOrderByColumn}>
                <SelectTrigger>
                  <SelectValue placeholder="Select column" />
                </SelectTrigger>
                <SelectContent>
                  {selectedTables.flatMap(table => 
                    tableSchema[table as keyof typeof tableSchema].map(column => (
                      <SelectItem key={`${table}.${column}`} value={`${table}.${column}`}>
                        {table}.{column}
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
              <Select value={orderDirection} onValueChange={(value: "ASC" | "DESC") => setOrderDirection(value)}>
                <SelectTrigger className="w-20">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ASC">ASC</SelectItem>
                  <SelectItem value="DESC">DESC</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="space-y-2">
            <h4 className="font-medium text-sm">Limit</h4>
            <Input
              type="number"
              placeholder="100"
              value={limitValue}
              onChange={(e) => setLimitValue(e.target.value)}
              min="1"
              max="10000"
            />
          </div>
        </div>

        {/* Generated SQL Preview */}
        {selectedTables.length > 0 && (
          <div className="space-y-2">
            <h4 className="font-medium text-sm">Generated SQL</h4>
            <pre className="bg-muted p-3 rounded-md text-xs overflow-x-auto">
              <code>{generateSQL()}</code>
            </pre>
          </div>
        )}

        {/* Execute Button */}
        <Button
          onClick={handleGenerateAndExecute}
          disabled={selectedTables.length === 0 || isGenerating}
          className="w-full"
          data-testid="execute-visual-query"
        >
          {isGenerating ? (
            <>
              <i className="fas fa-spinner fa-spin mr-2"></i>
              Executing Query...
            </>
          ) : (
            <>
              <i className="fas fa-play mr-2"></i>
              Execute Query
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );
}