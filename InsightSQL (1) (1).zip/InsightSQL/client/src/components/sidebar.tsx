import { Link, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useState } from "react";
import { apiRequest } from "@/lib/queryClient";

interface DataSourceStats {
  usersCount: number;
  featuresCount: number;
  userMetricsCount: number;
  eventsCount: number;
}

export function Sidebar() {
  const [location] = useLocation();
  const [showSeedPrompt, setShowSeedPrompt] = useState(false);

  const { data: stats, refetch } = useQuery<DataSourceStats>({
    queryKey: ['/api/data-sources'],
    refetchInterval: 30000, // Check every 30 seconds
  });

  const seedMutation = useMutation({
    mutationFn: () => apiRequest('POST', '/api/admin/seed'),
    onSuccess: () => {
      refetch();
      setShowSeedPrompt(false);
    },
  });

  const hasNoData = stats && stats.usersCount === 0 && stats.featuresCount === 0;

  const navigationItems = [
    { icon: "fas fa-search", label: "Query Builder", href: "/", active: location === "/" },
    { icon: "fas fa-chart-bar", label: "Dashboards", href: "/dashboards", active: location === "/dashboards" },
    { icon: "fas fa-database", label: "Data Sources", href: "/data-sources", active: location === "/data-sources" },
    { icon: "fas fa-bookmark", label: "Saved Queries", href: "/saved", active: location === "/saved" },
  ];

  const managementItems = [
    { icon: "fas fa-users", label: "Team", href: "/team", active: location === "/team" },
    { icon: "fas fa-cog", label: "Settings", href: "/settings", active: location === "/settings" },
  ];

  return (
    <div className="w-64 bg-card border-r border-border flex flex-col">
      {/* Logo and Brand */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <i className="fas fa-chart-line text-primary-foreground text-sm"></i>
          </div>
          <div>
            <h1 className="text-lg font-semibold text-foreground">DataInsight Pro</h1>
            <p className="text-xs text-muted-foreground">Product Analytics</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2">
        <div className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-3">Analytics</div>
        {navigationItems.map((item) => (
          <Link key={item.href} href={item.href}>
            <div
              className={`flex items-center space-x-3 px-3 py-2 rounded-md transition-colors cursor-pointer ${
                item.active
                  ? "bg-primary text-primary-foreground"
                  : "text-foreground hover:bg-muted"
              }`}
              data-testid={`nav-link-${item.label.toLowerCase().replace(" ", "-")}`}
            >
              <i className={`${item.icon} text-sm`}></i>
              <span className={item.active ? "font-medium" : ""}>{item.label}</span>
            </div>
          </Link>
        ))}

        <div className="text-xs font-medium text-muted-foreground uppercase tracking-wide mt-6 mb-3">Management</div>
        {managementItems.map((item) => (
          <Link key={item.href} href={item.href}>
            <div
              className={`flex items-center space-x-3 px-3 py-2 rounded-md transition-colors cursor-pointer ${
                item.active
                  ? "bg-primary text-primary-foreground"
                  : "text-foreground hover:bg-muted"
              }`}
              data-testid={`nav-link-${item.label.toLowerCase()}`}
            >
              <i className={`${item.icon} text-sm`}></i>
              <span>{item.label}</span>
            </div>
          </Link>
        ))}
      </nav>

      {/* Data Seeding Prompt */}
      {hasNoData && !showSeedPrompt && (
        <div className="p-4 border-t border-border bg-yellow-50 dark:bg-yellow-900/20">
          <div className="flex items-start space-x-2">
            <i className="fas fa-exclamation-triangle text-yellow-600 dark:text-yellow-400 text-sm mt-0.5"></i>
            <div className="flex-1">
              <p className="text-sm font-medium text-yellow-800 dark:text-yellow-200">No sample data found</p>
              <p className="text-xs text-yellow-600 dark:text-yellow-400 mt-1">
                Load sample data to start exploring analytics features
              </p>
              <button
                onClick={() => setShowSeedPrompt(true)}
                className="text-xs text-yellow-700 dark:text-yellow-300 underline hover:no-underline mt-1"
                data-testid="button-show-seed-prompt"
              >
                Load sample data →
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Seeding Action Panel */}
      {showSeedPrompt && (
        <div className="p-4 border-t border-border bg-blue-50 dark:bg-blue-900/20">
          <div className="space-y-3">
            <div className="flex items-center space-x-2">
              <i className="fas fa-database text-blue-600 dark:text-blue-400 text-sm"></i>
              <h3 className="text-sm font-medium text-blue-800 dark:text-blue-200">Load Sample Data</h3>
            </div>
            <p className="text-xs text-blue-600 dark:text-blue-400">
              This will create realistic sample data including users, features, metrics, and events for analytics demonstration.
            </p>
            <div className="flex space-x-2">
              <button
                onClick={() => seedMutation.mutate()}
                disabled={seedMutation.isPending}
                className="flex-1 px-3 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white text-xs rounded-md transition-colors"
                data-testid="button-seed-database"
              >
                {seedMutation.isPending ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-1"></i>
                    Loading...
                  </>
                ) : (
                  <>
                    <i className="fas fa-download mr-1"></i>
                    Load Data
                  </>
                )}
              </button>
              <button
                onClick={() => setShowSeedPrompt(false)}
                className="px-3 py-2 bg-gray-200 hover:bg-gray-300 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300 text-xs rounded-md transition-colors"
                data-testid="button-cancel-seed"
              >
                Cancel
              </button>
            </div>
            {seedMutation.isError && (
              <p className="text-xs text-red-600 dark:text-red-400">
                Failed to load sample data. Please try again.
              </p>
            )}
          </div>
        </div>
      )}

      {/* User Profile */}
      <div className="p-4 border-t border-border">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center">
            <span className="text-sm font-medium text-accent-foreground">JS</span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-foreground truncate">Jane Smith</p>
            <p className="text-xs text-muted-foreground truncate">Product Manager</p>
          </div>
          <button className="text-muted-foreground hover:text-foreground" data-testid="button-user-menu">
            <i className="fas fa-chevron-right text-xs"></i>
          </button>
        </div>
      </div>
    </div>
  );
}
