import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

export function ApiDocumentation() {
  const [selectedEndpoint, setSelectedEndpoint] = useState<string | null>(null);
  const [apiKey, setApiKey] = useState("sk_test_abcd1234efgh5678ijkl9012");
  const [webhookUrl, setWebhookUrl] = useState("");
  const { toast } = useToast();

  const apiEndpoints = [
    {
      id: "generate_query",
      method: "POST",
      path: "/api/queries/generate",
      description: "Generate SQL from natural language",
      parameters: {
        question: { type: "string", required: true, description: "Natural language question" }
      },
      response: {
        sql: "string",
        explanation: "string",
        confidence: "number"
      }
    },
    {
      id: "execute_query",
      method: "POST", 
      path: "/api/queries/execute",
      description: "Execute a SQL query",
      parameters: {
        sqlQuery: { type: "string", required: true, description: "SQL query to execute" },
        question: { type: "string", required: false, description: "Optional question for context" }
      },
      response: {
        results: "array",
        executionTime: "number",
        resultCount: "number"
      }
    },
    {
      id: "query_templates",
      method: "GET",
      path: "/api/query-templates",
      description: "Get available query templates",
      parameters: {
        category: { type: "string", required: false, description: "Filter by category" }
      },
      response: {
        templates: "array"
      }
    },
    {
      id: "insights",
      method: "GET",
      path: "/api/insights",
      description: "Get quick insights and metrics",
      parameters: {},
      response: {
        topEngagedUsers: "array",
        trendingFeatures: "array", 
        growthMetrics: "array",
        recentActivity: "array"
      }
    },
    {
      id: "export_data",
      method: "POST",
      path: "/api/queries/export",
      description: "Export query results",
      parameters: {
        format: { type: "string", required: true, description: "Export format (csv, json)" },
        data: { type: "array", required: true, description: "Data to export" },
        filename: { type: "string", required: false, description: "Optional filename" }
      },
      response: "File download"
    }
  ];

  const webhookEvents = [
    {
      event: "query.executed",
      description: "Triggered when a query is successfully executed",
      payload: {
        query_id: "string",
        question: "string",
        sql: "string",
        result_count: "number",
        execution_time: "number",
        timestamp: "ISO 8601 datetime"
      }
    },
    {
      event: "query.failed",
      description: "Triggered when a query execution fails",
      payload: {
        query_id: "string",
        question: "string", 
        sql: "string",
        error: "string",
        timestamp: "ISO 8601 datetime"
      }
    },
    {
      event: "template.used",
      description: "Triggered when a query template is used",
      payload: {
        template_id: "string",
        template_name: "string",
        category: "string",
        parameters: "object",
        timestamp: "ISO 8601 datetime"
      }
    },
    {
      event: "insight.generated",
      description: "Triggered when new insights are generated",
      payload: {
        insight_type: "string",
        data: "object",
        timestamp: "ISO 8601 datetime"
      }
    }
  ];

  const generateCurlExample = (endpoint: any) => {
    let curl = `curl -X ${endpoint.method} \\\n`;
    curl += `  "${window.location.origin}${endpoint.path}" \\\n`;
    curl += `  -H "Authorization: Bearer ${apiKey}" \\\n`;
    curl += `  -H "Content-Type: application/json"`;

    if (endpoint.method === "POST" && Object.keys(endpoint.parameters).length > 0) {
      curl += ` \\\n  -d '{\n`;
      const params = Object.entries(endpoint.parameters).map(([key, value]: [string, any]) => {
        const exampleValue = value.type === "string" ? `"example ${key}"` : 
                            value.type === "number" ? "42" :
                            value.type === "array" ? "[]" : "{}";
        return `    "${key}": ${exampleValue}`;
      });
      curl += params.join(",\n");
      curl += `\n  }'`;
    }

    return curl;
  };

  const generateJavaScriptExample = (endpoint: any) => {
    let js = `const response = await fetch('${window.location.origin}${endpoint.path}', {\n`;
    js += `  method: '${endpoint.method}',\n`;
    js += `  headers: {\n`;
    js += `    'Authorization': 'Bearer ${apiKey}',\n`;
    js += `    'Content-Type': 'application/json'\n`;
    js += `  }`;

    if (endpoint.method === "POST" && Object.keys(endpoint.parameters).length > 0) {
      js += `,\n  body: JSON.stringify({\n`;
      const params = Object.entries(endpoint.parameters).map(([key, value]: [string, any]) => {
        const exampleValue = value.type === "string" ? `"example ${key}"` : 
                            value.type === "number" ? 42 :
                            value.type === "array" ? "[]" : "{}";
        return `    ${key}: ${JSON.stringify(exampleValue)}`;
      });
      js += params.join(",\n");
      js += `\n  })`;
    }

    js += `\n});\n\nconst data = await response.json();\nconsole.log(data);`;
    return js;
  };

  const generateEmbedWidget = () => {
    const widgetCode = `<!-- DataInsight Pro Analytics Widget -->
<div id="datainsight-widget" style="width: 100%; height: 400px; border: 1px solid #e5e7eb; border-radius: 8px;"></div>

<script>
(function() {
  const script = document.createElement('script');
  script.src = '${window.location.origin}/widget.js';
  script.onload = function() {
    DataInsightWidget.init({
      containerId: 'datainsight-widget',
      apiKey: '${apiKey}',
      theme: 'light', // 'light' or 'dark'
      defaultQuery: 'Show me user engagement metrics',
      features: ['voice-input', 'export', 'templates']
    });
  };
  document.head.appendChild(script);
})();
</script>

<!-- React Component Example -->
<script type="text/babel">
const AnalyticsWidget = () => {
  const [data, setData] = React.useState(null);
  
  React.useEffect(() => {
    fetch('${window.location.origin}/api/insights', {
      headers: {
        'Authorization': 'Bearer ${apiKey}'
      }
    })
    .then(response => response.json())
    .then(data => setData(data));
  }, []);
  
  return (
    <div className="analytics-widget">
      {data ? (
        <div>
          <h3>Top Engaged Users</h3>
          {data.topEngagedUsers.map(user => (
            <div key={user.email}>{user.name}: {user.avg_engagement}</div>
          ))}
        </div>
      ) : (
        <div>Loading analytics...</div>
      )}
    </div>
  );
};
</script>`;

    return widgetCode;
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied to Clipboard",
      description: "Code example copied successfully",
    });
  };

  const testWebhook = () => {
    if (!webhookUrl) {
      toast({
        title: "Error",
        description: "Please enter a webhook URL",
        variant: "destructive",
      });
      return;
    }

    // Simulate webhook test
    toast({
      title: "Webhook Test Sent",
      description: "Test payload sent to your webhook URL",
    });
  };

  return (
    <div className="space-y-6" data-testid="api-documentation">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <i className="fas fa-code text-green-500"></i>
            <span>API Access & Integration</span>
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            Integrate DataInsight Pro into your applications with our REST API, webhooks, and embeddable widgets
          </p>
        </CardHeader>
      </Card>

      <Tabs defaultValue="endpoints" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="endpoints">REST API</TabsTrigger>
          <TabsTrigger value="webhooks">Webhooks</TabsTrigger>
          <TabsTrigger value="widgets">Widgets</TabsTrigger>
          <TabsTrigger value="examples">Examples</TabsTrigger>
        </TabsList>

        {/* REST API Documentation */}
        <TabsContent value="endpoints" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Available Endpoints</CardTitle>
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-muted-foreground">API Key:</span>
                  <Input
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                    className="text-xs font-mono"
                    data-testid="api-key-input"
                  />
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {apiEndpoints.map(endpoint => (
                  <div
                    key={endpoint.id}
                    className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                      selectedEndpoint === endpoint.id ? 'bg-muted border-primary' : 'hover:bg-muted/50'
                    }`}
                    onClick={() => setSelectedEndpoint(endpoint.id)}
                    data-testid={`endpoint-${endpoint.id}`}
                  >
                    <div className="flex items-center space-x-2 mb-1">
                      <Badge variant={
                        endpoint.method === 'GET' ? 'default' :
                        endpoint.method === 'POST' ? 'secondary' : 'outline'
                      }>
                        {endpoint.method}
                      </Badge>
                      <code className="text-sm">{endpoint.path}</code>
                    </div>
                    <p className="text-xs text-muted-foreground">{endpoint.description}</p>
                  </div>
                ))}
              </CardContent>
            </Card>

            {selectedEndpoint && (
              <Card>
                <CardHeader>
                  <CardTitle>Endpoint Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {(() => {
                    const endpoint = apiEndpoints.find(e => e.id === selectedEndpoint)!;
                    return (
                      <>
                        <div>
                          <h4 className="font-medium mb-2">Parameters</h4>
                          {Object.keys(endpoint.parameters).length > 0 ? (
                            <div className="space-y-2">
                              {Object.entries(endpoint.parameters).map(([key, value]: [string, any]) => (
                                <div key={key} className="flex justify-between text-sm">
                                  <span className="font-mono">{key}</span>
                                  <div className="text-right">
                                    <Badge variant="outline" className="text-xs mr-1">
                                      {value.type}
                                    </Badge>
                                    {value.required && (
                                      <Badge variant="destructive" className="text-xs">
                                        required
                                      </Badge>
                                    )}
                                  </div>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <p className="text-sm text-muted-foreground">No parameters required</p>
                          )}
                        </div>

                        <div>
                          <h4 className="font-medium mb-2">Response</h4>
                          <pre className="bg-muted p-3 rounded text-xs overflow-x-auto">
                            <code>{JSON.stringify(endpoint.response, null, 2)}</code>
                          </pre>
                        </div>

                        <div>
                          <h4 className="font-medium mb-2">cURL Example</h4>
                          <div className="relative">
                            <pre className="bg-muted p-3 rounded text-xs overflow-x-auto">
                              <code>{generateCurlExample(endpoint)}</code>
                            </pre>
                            <Button
                              size="sm"
                              variant="outline"
                              className="absolute top-2 right-2"
                              onClick={() => copyToClipboard(generateCurlExample(endpoint))}
                            >
                              <i className="fas fa-copy"></i>
                            </Button>
                          </div>
                        </div>

                        <div>
                          <h4 className="font-medium mb-2">JavaScript Example</h4>
                          <div className="relative">
                            <pre className="bg-muted p-3 rounded text-xs overflow-x-auto">
                              <code>{generateJavaScriptExample(endpoint)}</code>
                            </pre>
                            <Button
                              size="sm"
                              variant="outline"
                              className="absolute top-2 right-2"
                              onClick={() => copyToClipboard(generateJavaScriptExample(endpoint))}
                            >
                              <i className="fas fa-copy"></i>
                            </Button>
                          </div>
                        </div>
                      </>
                    );
                  })()}
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        {/* Webhooks */}
        <TabsContent value="webhooks" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Webhook Configuration</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium">Webhook URL</label>
                  <Input
                    placeholder="https://your-app.com/webhooks/datainsight"
                    value={webhookUrl}
                    onChange={(e) => setWebhookUrl(e.target.value)}
                    data-testid="webhook-url-input"
                  />
                </div>
                <Button onClick={testWebhook} data-testid="test-webhook">
                  <i className="fas fa-paper-plane mr-2"></i>
                  Test Webhook
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Available Events</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {webhookEvents.map(event => (
                  <div key={event.event} className="border rounded-lg p-3">
                    <div className="flex items-center space-x-2 mb-2">
                      <Badge>{event.event}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">{event.description}</p>
                    <details className="text-xs">
                      <summary className="cursor-pointer font-medium">Payload Structure</summary>
                      <pre className="bg-muted p-2 rounded mt-2 overflow-x-auto">
                        <code>{JSON.stringify(event.payload, null, 2)}</code>
                      </pre>
                    </details>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Embeddable Widgets */}
        <TabsContent value="widgets" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Embeddable Analytics Widget</CardTitle>
              <p className="text-sm text-muted-foreground">
                Embed DataInsight Pro directly into your application with our JavaScript widget
              </p>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium mb-2">Installation Code</h4>
                  <div className="relative">
                    <pre className="bg-muted p-4 rounded text-xs overflow-x-auto max-h-64">
                      <code>{generateEmbedWidget()}</code>
                    </pre>
                    <Button
                      size="sm"
                      variant="outline"
                      className="absolute top-2 right-2"
                      onClick={() => copyToClipboard(generateEmbedWidget())}
                      data-testid="copy-widget-code"
                    >
                      <i className="fas fa-copy mr-1"></i>
                      Copy
                    </Button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-medium mb-2">Widget Features</h4>
                    <ul className="text-sm space-y-1 text-muted-foreground">
                      <li>• Voice input integration</li>
                      <li>• Query templates</li>
                      <li>• Export functionality</li>
                      <li>• Real-time insights</li>
                      <li>• Customizable themes</li>
                      <li>• Responsive design</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-medium mb-2">Configuration Options</h4>
                    <ul className="text-sm space-y-1 text-muted-foreground">
                      <li>• <code>theme</code>: 'light' | 'dark'</li>
                      <li>• <code>defaultQuery</code>: string</li>
                      <li>• <code>features</code>: array</li>
                      <li>• <code>height</code>: number</li>
                      <li>• <code>autoRefresh</code>: boolean</li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Code Examples */}
        <TabsContent value="examples" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Python Example</CardTitle>
              </CardHeader>
              <CardContent>
                <pre className="bg-muted p-4 rounded text-xs overflow-x-auto">
                  <code>{`import requests

# DataInsight Pro Python SDK
class DataInsightClient:
    def __init__(self, api_key):
        self.api_key = api_key
        self.base_url = "${window.location.origin}"
        
    def generate_query(self, question):
        response = requests.post(
            f"{self.base_url}/api/queries/generate",
            headers={"Authorization": f"Bearer {self.api_key}"},
            json={"question": question}
        )
        return response.json()
    
    def execute_query(self, sql_query):
        response = requests.post(
            f"{self.base_url}/api/queries/execute", 
            headers={"Authorization": f"Bearer {self.api_key}"},
            json={"sqlQuery": sql_query}
        )
        return response.json()

# Usage example
client = DataInsightClient("${apiKey}")
query = client.generate_query("Show me user growth this month")
results = client.execute_query(query["sql"])
print(f"Found {results['resultCount']} results")`}</code>
                </pre>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Node.js Example</CardTitle>
              </CardHeader>
              <CardContent>
                <pre className="bg-muted p-4 rounded text-xs overflow-x-auto">
                  <code>{`const axios = require('axios');

class DataInsightClient {
  constructor(apiKey) {
    this.apiKey = apiKey;
    this.baseURL = '${window.location.origin}';
    this.client = axios.create({
      baseURL: this.baseURL,
      headers: {
        'Authorization': \`Bearer \${this.apiKey}\`,
        'Content-Type': 'application/json'
      }
    });
  }
  
  async generateQuery(question) {
    const response = await this.client.post('/api/queries/generate', {
      question
    });
    return response.data;
  }
  
  async executeQuery(sqlQuery) {
    const response = await this.client.post('/api/queries/execute', {
      sqlQuery
    });
    return response.data;
  }
  
  async getInsights() {
    const response = await this.client.get('/api/insights');
    return response.data;
  }
}

// Usage example
const client = new DataInsightClient('${apiKey}');

async function analyzeUserGrowth() {
  try {
    const query = await client.generateQuery('Show me user growth this month');
    const results = await client.executeQuery(query.sql);
    console.log(\`Found \${results.resultCount} results\`);
    return results;
  } catch (error) {
    console.error('Analysis failed:', error);
  }
}

analyzeUserGrowth();`}</code>
                </pre>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}