import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { QueryState } from "@/pages/dashboard";

interface QueryTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  question: string;
  sqlTemplate: string;
  parameters: any;
  usageCount: number;
}

interface QueryTemplatesProps {
  onSelectTemplate: (template: QueryState) => void;
}

export function QueryTemplates({ onSelectTemplate }: QueryTemplatesProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [selectedTemplate, setSelectedTemplate] = useState<QueryTemplate | null>(null);
  const [parameters, setParameters] = useState<Record<string, string>>({});
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: templates, isLoading } = useQuery<QueryTemplate[]>({
    queryKey: ['/api/query-templates', selectedCategory],
    queryFn: async () => {
      const response = await fetch(`/api/query-templates${selectedCategory ? `?category=${selectedCategory}` : ''}`);
      if (!response.ok) throw new Error('Failed to fetch templates');
      return response.json();
    }
  });

  const useTemplateMutation = useMutation({
    mutationFn: async ({ templateId, parameters }: { templateId: string; parameters: Record<string, string> }) => {
      return apiRequest('POST', `/api/query-templates/${templateId}/use`, { parameters });
    },
    onSuccess: async (response) => {
      const data = await response.json();
      onSelectTemplate({
        question: data.question,
        sql: data.sql,
        results: [],
        executionTime: 0,
        resultCount: 0,
        explanation: data.explanation,
      });
      toast({
        title: "Template Applied",
        description: `Using "${data.templateName}" template`,
      });
      setSelectedTemplate(null);
      setParameters({});
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to apply template",
        variant: "destructive",
      });
    }
  });

  const categories = templates ? [...new Set(templates.map(t => t.category))] : [];

  const handleTemplateSelect = (template: QueryTemplate) => {
    const templateParams = template.parameters ? JSON.parse(template.parameters) : {};
    
    if (Object.keys(templateParams).length === 0) {
      // No parameters needed, apply directly
      useTemplateMutation.mutate({ templateId: template.id, parameters: {} });
    } else {
      // Show parameter dialog
      setSelectedTemplate(template);
      const defaultParams: Record<string, string> = {};
      Object.entries(templateParams).forEach(([key, value]: [string, any]) => {
        defaultParams[key] = value.default || '';
      });
      setParameters(defaultParams);
    }
  };

  const handleApplyTemplate = () => {
    if (selectedTemplate) {
      useTemplateMutation.mutate({ 
        templateId: selectedTemplate.id, 
        parameters 
      });
    }
  };

  const getCategoryIcon = (category: string) => {
    const icons: Record<string, string> = {
      retention: "fas fa-undo",
      adoption: "fas fa-chart-line",
      conversion: "fas fa-funnel-dollar",
      cohort: "fas fa-users",
      growth: "fas fa-rocket",
      engagement: "fas fa-heart"
    };
    return icons[category] || "fas fa-chart-bar";
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      retention: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
      adoption: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
      conversion: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200",
      cohort: "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200",
      growth: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
      engagement: "bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-200"
    };
    return colors[category] || "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200";
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Smart Query Templates</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-20 bg-muted rounded-md"></div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <i className="fas fa-template text-primary"></i>
            <span>Smart Query Templates</span>
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            Pre-built queries for common product analytics scenarios
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Category Filter */}
          <div className="flex flex-wrap gap-2">
            <Button
              variant={selectedCategory === "" ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory("")}
              data-testid="category-filter-all"
            >
              All Categories
            </Button>
            {categories.map(category => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category)}
                data-testid={`category-filter-${category}`}
              >
                <i className={`${getCategoryIcon(category)} mr-1 text-xs`}></i>
                {category.charAt(0).toUpperCase() + category.slice(1)}
              </Button>
            ))}
          </div>

          {/* Templates Grid */}
          <div className="grid gap-3">
            {templates?.map(template => (
              <div
                key={template.id}
                className="p-3 border border-border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
                onClick={() => handleTemplateSelect(template)}
                data-testid={`template-${template.name.toLowerCase().replace(/\s+/g, '-')}`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <h4 className="font-medium text-sm text-foreground">{template.name}</h4>
                      <Badge variant="secondary" className={getCategoryColor(template.category)}>
                        {template.category}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mb-2">{template.description}</p>
                    <p className="text-xs italic text-muted-foreground">"{template.question}"</p>
                  </div>
                  <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                    <i className="fas fa-chart-bar"></i>
                    <span>{template.usageCount} uses</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {(!templates || templates.length === 0) && (
            <div className="text-center py-8">
              <i className="fas fa-template text-4xl text-muted-foreground mb-4"></i>
              <p className="text-lg font-medium text-foreground mb-2">No templates found</p>
              <p className="text-muted-foreground">
                {selectedCategory ? `No templates in the ${selectedCategory} category` : "No query templates available"}
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Parameter Dialog */}
      <Dialog open={selectedTemplate !== null} onOpenChange={(open) => !open && setSelectedTemplate(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Configure Template: {selectedTemplate?.name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              {selectedTemplate?.description}
            </p>
            
            {selectedTemplate && Object.entries(
              selectedTemplate.parameters ? JSON.parse(selectedTemplate.parameters) : {}
            ).map(([key, config]: [string, any]) => (
              <div key={key} className="space-y-2">
                <Label htmlFor={key} className="text-sm font-medium">
                  {key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                </Label>
                <Input
                  id={key}
                  value={parameters[key] || ''}
                  onChange={(e) => setParameters(prev => ({ ...prev, [key]: e.target.value }))}
                  placeholder={config.description || config.default}
                  data-testid={`parameter-${key}`}
                />
                {config.description && (
                  <p className="text-xs text-muted-foreground">{config.description}</p>
                )}
              </div>
            ))}
            
            <div className="flex justify-end space-x-2 pt-4">
              <Button 
                variant="outline" 
                onClick={() => setSelectedTemplate(null)}
                data-testid="button-cancel-template"
              >
                Cancel
              </Button>
              <Button 
                onClick={handleApplyTemplate}
                disabled={useTemplateMutation.isPending}
                data-testid="button-apply-template"
              >
                {useTemplateMutation.isPending ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    Applying...
                  </>
                ) : (
                  <>
                    <i className="fas fa-play mr-2"></i>
                    Apply Template
                  </>
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}