import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDistanceToNow } from "date-fns";

interface QueryHistoryProps {
  onSelectQuery: (question: string) => void;
}

interface QueryData {
  id: string;
  question: string;
  createdAt: string;
}

interface DataStats {
  usersCount: number;
  featuresCount: number;
  userMetricsCount: number;
  eventsCount: number;
}

export function QueryHistory({ onSelectQuery }: QueryHistoryProps) {
  const { data: queries, isLoading: queriesLoading } = useQuery<QueryData[]>({
    queryKey: ["/api/queries/history"],
  });

  const { data: dataStats, isLoading: statsLoading } = useQuery<DataStats>({
    queryKey: ["/api/data-sources"],
  });

  const formatTimeAgo = (dateString: string) => {
    try {
      return formatDistanceToNow(new Date(dateString), { addSuffix: true });
    } catch {
      return "Unknown";
    }
  };

  if (queriesLoading || statsLoading) {
    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-32" />
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="p-3 bg-muted rounded-md">
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-3 w-16" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-32" />
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="flex items-center space-x-3">
                  <Skeleton className="w-3 h-3 rounded-full" />
                  <div className="flex-1">
                    <Skeleton className="h-4 w-20 mb-1" />
                    <Skeleton className="h-3 w-16" />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Query History */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Queries</CardTitle>
        </CardHeader>
        <CardContent>
          {queries && queries.length > 0 ? (
            <div className="space-y-3">
              {queries.map((query) => (
                <div
                  key={query.id}
                  className="p-3 bg-muted rounded-md cursor-pointer hover:bg-accent hover:text-accent-foreground transition-colors group"
                  onClick={() => onSelectQuery(query.question)}
                  data-testid={`history-item-${query.id}`}
                >
                  <p className="text-sm font-medium group-hover:text-accent-foreground line-clamp-2">
                    {query.question}
                  </p>
                  <p className="text-xs text-muted-foreground group-hover:text-accent-foreground/80 mt-1">
                    {formatTimeAgo(query.createdAt)}
                  </p>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-4">
              <p className="text-sm text-muted-foreground">No recent queries</p>
            </div>
          )}
          <div className="pt-4 border-t border-border mt-4">
            <Button variant="ghost" className="w-full text-sm text-muted-foreground hover:text-foreground" data-testid="button-view-all-history">
              View all history <i className="fas fa-arrow-right ml-1"></i>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Data Sources */}
      <Card>
        <CardHeader>
          <CardTitle>Data Sources</CardTitle>
        </CardHeader>
        <CardContent>
          {dataStats ? (
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-accent rounded-full"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-foreground">Users</p>
                  <p className="text-xs text-muted-foreground" data-testid="text-users-count">
                    {dataStats.usersCount.toLocaleString()} records
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-chart-2 rounded-full"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-foreground">Features</p>
                  <p className="text-xs text-muted-foreground" data-testid="text-features-count">
                    {dataStats.featuresCount.toLocaleString()} records
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-chart-3 rounded-full"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-foreground">User Metrics</p>
                  <p className="text-xs text-muted-foreground" data-testid="text-metrics-count">
                    {dataStats.userMetricsCount.toLocaleString()} records
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-chart-4 rounded-full"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-foreground">Events</p>
                  <p className="text-xs text-muted-foreground" data-testid="text-events-count">
                    {dataStats.eventsCount.toLocaleString()} records
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-4">
              <p className="text-sm text-muted-foreground">Unable to load data sources</p>
            </div>
          )}
          <div className="pt-4 border-t border-border mt-4">
            <Button variant="ghost" className="w-full text-sm text-muted-foreground hover:text-foreground" data-testid="button-explore-schema">
              Explore schema <i className="fas fa-external-link-alt ml-1"></i>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Quick Metrics */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Metrics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-foreground" data-testid="text-avg-engagement">-</p>
              <p className="text-xs text-muted-foreground">Avg Engagement Score</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-foreground" data-testid="text-active-users">
                {dataStats?.usersCount ? dataStats.usersCount.toLocaleString() : "-"}
              </p>
              <p className="text-xs text-muted-foreground">Total Users</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-accent" data-testid="text-growth">-</p>
              <p className="text-xs text-muted-foreground">Growth vs Last Quarter</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
