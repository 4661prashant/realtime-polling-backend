import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

interface RealTimeMetric {
  id: string;
  title: string;
  value: number | string;
  change: number;
  trend: 'up' | 'down' | 'stable';
  timestamp: Date;
  type: 'count' | 'percentage' | 'duration' | 'currency';
}

interface NotificationAlert {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'warning' | 'success' | 'error';
  timestamp: Date;
}

export function RealTimeMetrics() {
  const [isConnected, setIsConnected] = useState(false);
  const [isLiveUpdatesEnabled, setIsLiveUpdatesEnabled] = useState(true);
  const [metrics, setMetrics] = useState<RealTimeMetric[]>([]);
  const [notifications, setNotifications] = useState<NotificationAlert[]>([]);
  const [connectionStatus, setConnectionStatus] = useState<'connecting' | 'connected' | 'disconnected'>('disconnected');
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const simulationIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const { toast } = useToast();

  // Initialize metrics with some base values
  const initializeMetrics = () => {
    const baseMetrics: RealTimeMetric[] = [
      {
        id: 'active_users',
        title: 'Active Users',
        value: 1247,
        change: 0,
        trend: 'stable',
        timestamp: new Date(),
        type: 'count'
      },
      {
        id: 'queries_per_minute',
        title: 'Queries/Min',
        value: 23,
        change: 0,
        trend: 'stable',
        timestamp: new Date(),
        type: 'count'
      },
      {
        id: 'avg_response_time',
        title: 'Avg Response Time',
        value: 145,
        change: 0,
        trend: 'stable',
        timestamp: new Date(),
        type: 'duration'
      },
      {
        id: 'success_rate',
        title: 'Success Rate',
        value: 98.7,
        change: 0,
        trend: 'stable',
        timestamp: new Date(),
        type: 'percentage'
      },
      {
        id: 'new_signups',
        title: 'New Signups Today',
        value: 156,
        change: 0,
        trend: 'stable',
        timestamp: new Date(),
        type: 'count'
      },
      {
        id: 'revenue_today',
        title: 'Revenue Today',
        value: 12450,
        change: 0,
        trend: 'stable',
        timestamp: new Date(),
        type: 'currency'
      }
    ];
    setMetrics(baseMetrics);
  };

  // Simulate real-time WebSocket connection
  const connectWebSocket = () => {
    if (!isLiveUpdatesEnabled) return;

    setConnectionStatus('connecting');
    
    // Simulate WebSocket connection
    setTimeout(() => {
      setIsConnected(true);
      setConnectionStatus('connected');
      
      toast({
        title: "Real-time Updates Connected",
        description: "Now receiving live metrics updates",
      });

      // Start simulation of real-time data
      startDataSimulation();
    }, 1000);
  };

  const disconnectWebSocket = () => {
    setIsConnected(false);
    setConnectionStatus('disconnected');
    
    if (simulationIntervalRef.current) {
      clearInterval(simulationIntervalRef.current);
      simulationIntervalRef.current = null;
    }
    
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }
  };

  const startDataSimulation = () => {
    if (simulationIntervalRef.current) return;

    simulationIntervalRef.current = setInterval(() => {
      setMetrics(prevMetrics => 
        prevMetrics.map(metric => {
          const variation = (Math.random() - 0.5) * 0.1; // ±10% variation
          let newValue = metric.value;
          let change = 0;
          
          if (metric.type === 'count') {
            const baseValue = typeof metric.value === 'number' ? metric.value : 0;
            newValue = Math.max(0, Math.round(baseValue * (1 + variation)));
            change = newValue - baseValue;
          } else if (metric.type === 'percentage') {
            const baseValue = typeof metric.value === 'number' ? metric.value : 0;
            newValue = Math.max(0, Math.min(100, baseValue + (variation * 5)));
            change = newValue - baseValue;
          } else if (metric.type === 'duration') {
            const baseValue = typeof metric.value === 'number' ? metric.value : 0;
            newValue = Math.max(1, Math.round(baseValue * (1 + variation)));
            change = newValue - baseValue;
          } else if (metric.type === 'currency') {
            const baseValue = typeof metric.value === 'number' ? metric.value : 0;
            newValue = Math.max(0, Math.round(baseValue * (1 + variation)));
            change = newValue - baseValue;
          }

          const trend: 'up' | 'down' | 'stable' = 
            change > 0 ? 'up' : 
            change < 0 ? 'down' : 'stable';

          // Generate notifications for significant changes
          if (Math.abs(change) > (typeof metric.value === 'number' ? metric.value * 0.15 : 0)) {
            const notification: NotificationAlert = {
              id: `${metric.id}_${Date.now()}`,
              title: `${metric.title} Alert`,
              message: `${metric.title} ${trend === 'up' ? 'increased' : 'decreased'} by ${Math.abs(change).toFixed(1)}${metric.type === 'percentage' ? '%' : ''}`,
              type: trend === 'up' ? 'success' : trend === 'down' ? 'warning' : 'info',
              timestamp: new Date()
            };
            
            setNotifications(prev => [notification, ...prev.slice(0, 4)]);
            
            toast({
              title: notification.title,
              description: notification.message,
              variant: notification.type === 'warning' ? 'destructive' : 'default',
            });
          }

          return {
            ...metric,
            value: newValue,
            change,
            trend,
            timestamp: new Date()
          };
        })
      );
    }, 3000 + Math.random() * 2000); // Random interval between 3-5 seconds
  };

  useEffect(() => {
    initializeMetrics();
    
    if (isLiveUpdatesEnabled) {
      connectWebSocket();
    }

    return () => {
      disconnectWebSocket();
    };
  }, [isLiveUpdatesEnabled]);

  const formatValue = (value: number | string, type: RealTimeMetric['type']) => {
    if (typeof value === 'string') return value;
    
    switch (type) {
      case 'count':
        return value.toLocaleString();
      case 'percentage':
        return `${value.toFixed(1)}%`;
      case 'duration':
        return `${value}ms`;
      case 'currency':
        return `$${value.toLocaleString()}`;
      default:
        return value.toString();
    }
  };

  const getTrendIcon = (trend: RealTimeMetric['trend']) => {
    switch (trend) {
      case 'up':
        return 'fas fa-arrow-up text-green-500';
      case 'down':
        return 'fas fa-arrow-down text-red-500';
      default:
        return 'fas fa-minus text-gray-500';
    }
  };

  const getChangeColor = (change: number, trend: RealTimeMetric['trend']) => {
    if (trend === 'up') return 'text-green-600 dark:text-green-400';
    if (trend === 'down') return 'text-red-600 dark:text-red-400';
    return 'text-gray-600 dark:text-gray-400';
  };

  return (
    <div className="space-y-6" data-testid="real-time-metrics">
      {/* Connection Status & Controls */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center space-x-2">
              <i className="fas fa-broadcast-tower text-blue-500"></i>
              <span>Real-time Metrics</span>
              <Badge 
                variant={isConnected ? "default" : "secondary"}
                className={isConnected ? "bg-green-500" : "bg-gray-500"}
              >
                {connectionStatus}
              </Badge>
            </CardTitle>
            <div className="flex items-center space-x-2">
              <Label htmlFor="live-updates" className="text-sm">
                Live Updates
              </Label>
              <Switch
                id="live-updates"
                checked={isLiveUpdatesEnabled}
                onCheckedChange={setIsLiveUpdatesEnabled}
                data-testid="toggle-live-updates"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500 animate-pulse' : 'bg-gray-400'}`}></div>
              <span className="text-sm text-muted-foreground">
                {isConnected ? 'Receiving live data' : 'Disconnected'}
              </span>
            </div>
            <Button
              size="sm"
              variant="outline"
              onClick={() => setIsLiveUpdatesEnabled(!isLiveUpdatesEnabled)}
              data-testid="reconnect-button"
            >
              {isConnected ? (
                <>
                  <i className="fas fa-pause mr-2"></i>
                  Pause
                </>
              ) : (
                <>
                  <i className="fas fa-play mr-2"></i>
                  Connect
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {metrics.map(metric => (
          <Card key={metric.id} className="relative">
            {isConnected && (
              <div className="absolute top-2 right-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              </div>
            )}
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-sm font-medium text-muted-foreground">
                  {metric.title}
                </h4>
                <i className={getTrendIcon(metric.trend)}></i>
              </div>
              <div className="space-y-1">
                <div className="text-2xl font-bold" data-testid={`metric-${metric.id}-value`}>
                  {formatValue(metric.value, metric.type)}
                </div>
                {metric.change !== 0 && (
                  <div className={`text-xs ${getChangeColor(metric.change, metric.trend)}`}>
                    {metric.change > 0 ? '+' : ''}{formatValue(metric.change, metric.type)} 
                    <span className="text-muted-foreground ml-1">
                      since last update
                    </span>
                  </div>
                )}
                <div className="text-xs text-muted-foreground">
                  Updated {metric.timestamp.toLocaleTimeString()}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Recent Alerts */}
      {notifications.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <i className="fas fa-bell text-yellow-500"></i>
              <span>Recent Alerts</span>
              <Badge variant="secondary">{notifications.length}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {notifications.map(notification => (
                <div
                  key={notification.id}
                  className="flex items-start space-x-3 p-3 rounded-lg bg-muted/50"
                  data-testid={`notification-${notification.id}`}
                >
                  <i className={`fas fa-circle text-xs mt-1 ${
                    notification.type === 'success' ? 'text-green-500' :
                    notification.type === 'warning' ? 'text-yellow-500' :
                    notification.type === 'error' ? 'text-red-500' :
                    'text-blue-500'
                  }`}></i>
                  <div className="flex-1">
                    <p className="font-medium text-sm">{notification.title}</p>
                    <p className="text-sm text-muted-foreground">{notification.message}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {notification.timestamp.toLocaleTimeString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}