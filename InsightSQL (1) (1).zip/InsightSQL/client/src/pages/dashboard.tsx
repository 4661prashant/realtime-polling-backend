import { Sidebar } from "@/components/sidebar";
import { QueryBuilder } from "@/components/query-builder";
import { QueryResults } from "@/components/query-results";
import { QueryHistory } from "@/components/query-history";
import { QueryTemplates } from "@/components/query-templates";
import { QuickInsights } from "@/components/quick-insights";
import { InteractiveQueryBuilder } from "@/components/interactive-query-builder";
import { RealTimeMetrics } from "@/components/real-time-metrics";
import { ApiDocumentation } from "@/components/api-documentation";
import { useState } from "react";

export interface QueryState {
  question: string;
  sql: string;
  results: any[];
  executionTime: number;
  resultCount: number;
  explanation: string;
}

export default function Dashboard() {
  const [queryState, setQueryState] = useState<QueryState>({
    question: "",
    sql: "",
    results: [],
    executionTime: 0,
    resultCount: 0,
    explanation: "",
  });

  const [isLoading, setIsLoading] = useState(false);

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-card border-b border-border px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-semibold text-foreground">Natural Language Query Builder</h2>
              <p className="text-sm text-muted-foreground">Ask questions about your product data in plain English</p>
            </div>
            <div className="flex items-center space-x-3">
              <button 
                className="px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground border border-border rounded-md hover:bg-muted transition-colors"
                data-testid="button-history"
              >
                <i className="fas fa-history mr-2"></i>
                History
              </button>
              <button 
                className="px-4 py-2 text-sm font-medium bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-colors disabled:opacity-50"
                disabled={!queryState.sql}
                data-testid="button-save-query"
              >
                <i className="fas fa-save mr-2"></i>
                Save Query
              </button>
            </div>
          </div>
        </header>

        <QueryBuilder 
          queryState={queryState}
          setQueryState={setQueryState}
          isLoading={isLoading}
          setIsLoading={setIsLoading}
        />

        {/* Main Content Area */}
        <div className="flex-1 overflow-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 p-6 h-full">
            <div className="lg:col-span-2">
              <QueryResults queryState={queryState} isLoading={isLoading} />
            </div>
            <div className="space-y-6">
              <QueryTemplates onSelectTemplate={setQueryState} />
              <QuickInsights />
              <QueryHistory onSelectQuery={(question) => 
                setQueryState(prev => ({ ...prev, question }))
              } />
            </div>
          </div>
        </div>

        {/* Additional Features Panel */}
        <div className="border-t border-border p-6 bg-muted/30">
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            <InteractiveQueryBuilder onQueryGenerated={setQueryState} />
            <RealTimeMetrics />
            <ApiDocumentation />
          </div>
        </div>
      </div>
    </div>
  );
}
