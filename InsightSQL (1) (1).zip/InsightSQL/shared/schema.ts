import { sql, relations } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, decimal, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  signupDate: timestamp("signup_date").notNull().defaultNow(),
  plan: text("plan").notNull().default("free"),
  status: text("status").notNull().default("active"),
});

export const features = pgTable("features", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull().unique(),
  description: text("description"),
  category: text("category").notNull(),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const userFeatures = pgTable("user_features", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  featureId: varchar("feature_id").notNull().references(() => features.id),
  firstUsed: timestamp("first_used").notNull().defaultNow(),
  lastUsed: timestamp("last_used").notNull().defaultNow(),
  usageCount: integer("usage_count").notNull().default(0),
});

export const userMetrics = pgTable("user_metrics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  date: timestamp("date").notNull(),
  engagementScore: decimal("engagement_score", { precision: 3, scale: 1 }).notNull(),
  sessionDuration: integer("session_duration").notNull(), // in minutes
  actionsCount: integer("actions_count").notNull(),
});

export const events = pgTable("events", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  featureId: varchar("feature_id").references(() => features.id),
  eventType: text("event_type").notNull(),
  eventData: jsonb("event_data"),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const queries = pgTable("queries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  question: text("question").notNull(),
  sqlQuery: text("sql_query").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  executionTime: decimal("execution_time", { precision: 6, scale: 3 }),
  resultCount: integer("result_count"),
  isSaved: boolean("is_saved").notNull().default(false),
});

export const queryTemplates = pgTable("query_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  question: text("question").notNull(),
  sqlTemplate: text("sql_template").notNull(),
  parameters: jsonb("parameters"),
  isActive: boolean("is_active").notNull().default(true),
  usageCount: integer("usage_count").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const sharedQueries = pgTable("shared_queries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  queryId: varchar("query_id").notNull().references(() => queries.id),
  shareToken: text("share_token").notNull().unique(),
  isPublic: boolean("is_public").notNull().default(false),
  expiresAt: timestamp("expires_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  userFeatures: many(userFeatures),
  userMetrics: many(userMetrics),
  events: many(events),
}));

export const featuresRelations = relations(features, ({ many }) => ({
  userFeatures: many(userFeatures),
  events: many(events),
}));

export const userFeaturesRelations = relations(userFeatures, ({ one }) => ({
  user: one(users, {
    fields: [userFeatures.userId],
    references: [users.id],
  }),
  feature: one(features, {
    fields: [userFeatures.featureId],
    references: [features.id],
  }),
}));

export const userMetricsRelations = relations(userMetrics, ({ one }) => ({
  user: one(users, {
    fields: [userMetrics.userId],
    references: [users.id],
  }),
}));

export const eventsRelations = relations(events, ({ one }) => ({
  user: one(users, {
    fields: [events.userId],
    references: [users.id],
  }),
  feature: one(features, {
    fields: [events.featureId],
    references: [features.id],
  }),
}));

// Schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  signupDate: true,
});

export const insertFeatureSchema = createInsertSchema(features).omit({
  id: true,
  createdAt: true,
});

export const insertUserFeatureSchema = createInsertSchema(userFeatures).omit({
  id: true,
  firstUsed: true,
  lastUsed: true,
});

export const insertUserMetricSchema = createInsertSchema(userMetrics).omit({
  id: true,
});

export const insertEventSchema = createInsertSchema(events).omit({
  id: true,
  timestamp: true,
});

export const insertQuerySchema = createInsertSchema(queries).omit({
  id: true,
  createdAt: true,
});

export const insertQueryTemplateSchema = createInsertSchema(queryTemplates).omit({
  id: true,
  createdAt: true,
  usageCount: true,
});

export const insertSharedQuerySchema = createInsertSchema(sharedQueries).omit({
  id: true,
  createdAt: true,
});

export const selectQuerySchema = createSelectSchema(queries);
export const selectQueryTemplateSchema = createSelectSchema(queryTemplates);
export const selectSharedQuerySchema = createSelectSchema(sharedQueries);

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Feature = typeof features.$inferSelect;
export type InsertFeature = z.infer<typeof insertFeatureSchema>;
export type UserFeature = typeof userFeatures.$inferSelect;
export type InsertUserFeature = z.infer<typeof insertUserFeatureSchema>;
export type UserMetric = typeof userMetrics.$inferSelect;
export type InsertUserMetric = z.infer<typeof insertUserMetricSchema>;
export type Event = typeof events.$inferSelect;
export type InsertEvent = z.infer<typeof insertEventSchema>;
export type Query = typeof queries.$inferSelect;
export type InsertQuery = z.infer<typeof insertQuerySchema>;
export type QueryTemplate = typeof queryTemplates.$inferSelect;
export type InsertQueryTemplate = z.infer<typeof insertQueryTemplateSchema>;
export type SharedQuery = typeof sharedQueries.$inferSelect;
export type InsertSharedQuery = z.infer<typeof insertSharedQuerySchema>;
