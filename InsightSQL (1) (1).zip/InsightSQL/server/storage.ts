import { 
  users, features, userFeatures, userMetrics, events, queries, queryTemplates, sharedQueries,
  type User, type InsertUser, type Feature, type InsertFeature,
  type UserFeature, type InsertUserFeature, type UserMetric, type InsertUserMetric,
  type Event, type InsertEvent, type Query, type InsertQuery,
  type QueryTemplate, type InsertQueryTemplate, type SharedQuery, type InsertSharedQuery
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql, and, gte, count } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Features
  getAllFeatures(): Promise<Feature[]>;
  createFeature(feature: InsertFeature): Promise<Feature>;
  
  // User Features
  getUserFeatures(userId: string): Promise<UserFeature[]>;
  createUserFeature(userFeature: InsertUserFeature): Promise<UserFeature>;
  
  // User Metrics
  getUserMetrics(userId: string): Promise<UserMetric[]>;
  createUserMetric(userMetric: InsertUserMetric): Promise<UserMetric>;
  
  // Events
  getEvents(limit?: number): Promise<Event[]>;
  createEvent(event: InsertEvent): Promise<Event>;
  
  // Queries
  getQueries(limit?: number): Promise<Query[]>;
  getSavedQueries(): Promise<Query[]>;
  createQuery(query: InsertQuery): Promise<Query>;
  saveQuery(id: string): Promise<Query>;
  
  // Query Templates
  getQueryTemplates(category?: string): Promise<QueryTemplate[]>;
  getQueryTemplate(id: string): Promise<QueryTemplate | undefined>;
  createQueryTemplate(template: InsertQueryTemplate): Promise<QueryTemplate>;
  incrementTemplateUsage(id: string): Promise<void>;
  
  // Shared Queries
  createSharedQuery(sharedQuery: InsertSharedQuery): Promise<SharedQuery>;
  getSharedQuery(shareToken: string): Promise<SharedQuery | undefined>;
  
  // Analytics & Insights
  executeRawQuery(sqlQuery: string): Promise<any[]>;
  getDataSourceStats(): Promise<{
    usersCount: number;
    featuresCount: number;
    userMetricsCount: number;
    eventsCount: number;
  }>;
  getQuickInsights(): Promise<{
    topEngagedUsers: any[];
    trendingFeatures: any[];
    growthMetrics: any[];
    recentActivity: any[];
  }>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getAllFeatures(): Promise<Feature[]> {
    return await db.select().from(features).where(eq(features.isActive, true));
  }

  async createFeature(insertFeature: InsertFeature): Promise<Feature> {
    const [feature] = await db
      .insert(features)
      .values(insertFeature)
      .returning();
    return feature;
  }

  async getUserFeatures(userId: string): Promise<UserFeature[]> {
    return await db.select().from(userFeatures).where(eq(userFeatures.userId, userId));
  }

  async createUserFeature(insertUserFeature: InsertUserFeature): Promise<UserFeature> {
    const [userFeature] = await db
      .insert(userFeatures)
      .values(insertUserFeature)
      .returning();
    return userFeature;
  }

  async getUserMetrics(userId: string): Promise<UserMetric[]> {
    return await db.select().from(userMetrics)
      .where(eq(userMetrics.userId, userId))
      .orderBy(desc(userMetrics.date));
  }

  async createUserMetric(insertUserMetric: InsertUserMetric): Promise<UserMetric> {
    const [userMetric] = await db
      .insert(userMetrics)
      .values(insertUserMetric)
      .returning();
    return userMetric;
  }

  async getEvents(limit: number = 100): Promise<Event[]> {
    return await db.select().from(events)
      .orderBy(desc(events.timestamp))
      .limit(limit);
  }

  async createEvent(insertEvent: InsertEvent): Promise<Event> {
    const [event] = await db
      .insert(events)
      .values(insertEvent)
      .returning();
    return event;
  }

  async getQueries(limit: number = 10): Promise<Query[]> {
    return await db.select().from(queries)
      .orderBy(desc(queries.createdAt))
      .limit(limit);
  }

  async getSavedQueries(): Promise<Query[]> {
    return await db.select().from(queries)
      .where(eq(queries.isSaved, true))
      .orderBy(desc(queries.createdAt));
  }

  async createQuery(insertQuery: InsertQuery): Promise<Query> {
    const [query] = await db
      .insert(queries)
      .values(insertQuery)
      .returning();
    return query;
  }

  async saveQuery(id: string): Promise<Query> {
    const [query] = await db
      .update(queries)
      .set({ isSaved: true })
      .where(eq(queries.id, id))
      .returning();
    return query;
  }

  async executeRawQuery(sqlQuery: string): Promise<any[]> {
    try {
      const result = await db.execute(sql.raw(sqlQuery));
      return result.rows as any[];
    } catch (error) {
      throw new Error(`Query execution failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getDataSourceStats(): Promise<{
    usersCount: number;
    featuresCount: number;
    userMetricsCount: number;
    eventsCount: number;
  }> {
    const [usersCountResult] = await db.select({ count: count() }).from(users);
    const [featuresCountResult] = await db.select({ count: count() }).from(features);
    const [userMetricsCountResult] = await db.select({ count: count() }).from(userMetrics);
    const [eventsCountResult] = await db.select({ count: count() }).from(events);

    return {
      usersCount: usersCountResult.count,
      featuresCount: featuresCountResult.count,
      userMetricsCount: userMetricsCountResult.count,
      eventsCount: eventsCountResult.count,
    };
  }

  // Query Templates Methods
  async getQueryTemplates(category?: string): Promise<QueryTemplate[]> {
    let query = db.select().from(queryTemplates).where(eq(queryTemplates.isActive, true));
    
    if (category) {
      query = query.where(eq(queryTemplates.category, category));
    }
    
    return await query.orderBy(desc(queryTemplates.usageCount));
  }

  async getQueryTemplate(id: string): Promise<QueryTemplate | undefined> {
    const [template] = await db.select().from(queryTemplates).where(eq(queryTemplates.id, id));
    return template || undefined;
  }

  async createQueryTemplate(insertTemplate: InsertQueryTemplate): Promise<QueryTemplate> {
    const [template] = await db
      .insert(queryTemplates)
      .values(insertTemplate)
      .returning();
    return template;
  }

  async incrementTemplateUsage(id: string): Promise<void> {
    await db
      .update(queryTemplates)
      .set({ usageCount: sql`${queryTemplates.usageCount} + 1` })
      .where(eq(queryTemplates.id, id));
  }

  // Shared Queries Methods
  async createSharedQuery(insertSharedQuery: InsertSharedQuery): Promise<SharedQuery> {
    const [sharedQuery] = await db
      .insert(sharedQueries)
      .values(insertSharedQuery)
      .returning();
    return sharedQuery;
  }

  async getSharedQuery(shareToken: string): Promise<SharedQuery | undefined> {
    const [sharedQuery] = await db.select().from(sharedQueries)
      .where(eq(sharedQueries.shareToken, shareToken));
    return sharedQuery || undefined;
  }

  // Quick Insights Methods
  async getQuickInsights(): Promise<{
    topEngagedUsers: any[];
    trendingFeatures: any[];
    growthMetrics: any[];
    recentActivity: any[];
  }> {
    // Top engaged users (by recent engagement score)
    const topEngagedUsers = await db.execute(sql`
      SELECT u.name, u.email, AVG(um.engagement_score) as avg_engagement,
             COUNT(um.id) as metrics_count
      FROM users u
      JOIN user_metrics um ON u.id = um.user_id
      WHERE um.date >= NOW() - INTERVAL '30 days'
      GROUP BY u.id, u.name, u.email
      ORDER BY avg_engagement DESC
      LIMIT 5
    `);

    // Trending features (most used recently)
    const trendingFeatures = await db.execute(sql`
      SELECT f.name, f.category, COUNT(uf.id) as usage_count,
             COUNT(DISTINCT uf.user_id) as unique_users
      FROM features f
      JOIN user_features uf ON f.id = uf.feature_id
      WHERE uf.last_used >= NOW() - INTERVAL '7 days'
      GROUP BY f.id, f.name, f.category
      ORDER BY usage_count DESC
      LIMIT 5
    `);

    // Growth metrics
    const growthMetrics = await db.execute(sql`
      SELECT 
        DATE_TRUNC('day', signup_date) as date,
        COUNT(*) as new_users
      FROM users
      WHERE signup_date >= NOW() - INTERVAL '30 days'
      GROUP BY DATE_TRUNC('day', signup_date)
      ORDER BY date DESC
      LIMIT 30
    `);

    // Recent activity
    const recentActivity = await db.execute(sql`
      SELECT e.event_type, u.name as user_name, f.name as feature_name,
             e.timestamp
      FROM events e
      JOIN users u ON e.user_id = u.id
      LEFT JOIN features f ON e.feature_id = f.id
      ORDER BY e.timestamp DESC
      LIMIT 10
    `);

    return {
      topEngagedUsers: topEngagedUsers.rows as any[],
      trendingFeatures: trendingFeatures.rows as any[],
      growthMetrics: growthMetrics.rows as any[],
      recentActivity: recentActivity.rows as any[],
    };
  }
}

export const storage = new DatabaseStorage();
