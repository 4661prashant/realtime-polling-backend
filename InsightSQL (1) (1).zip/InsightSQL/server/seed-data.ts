import { storage } from "./storage";
import type { InsertUser, InsertFeature, InsertUserFeature, InsertUserMetric, InsertEvent, InsertQueryTemplate } from "@shared/schema";

// Helper function to generate random dates
function getRandomDate(start: Date, end: Date): Date {
  return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
}

// Helper function to generate random number in range
function getRandomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Helper function to get random item from array
function getRandomItem<T>(array: T[]): T {
  return array[Math.floor(Math.random() * array.length)];
}

// Sample data generators
export async function seedDatabase() {
  console.log("Starting database seeding...");
  
  // Check if data already exists
  const existingStats = await storage.getDataSourceStats();
  if (existingStats.usersCount > 0) {
    console.log("Database already contains data. Skipping seeding to prevent duplicates.");
    console.log(`Current stats: Users: ${existingStats.usersCount}, Features: ${existingStats.featuresCount}, Metrics: ${existingStats.userMetricsCount}, Events: ${existingStats.eventsCount}`);
    return existingStats;
  }
  
  // Step 1: Create realistic users (product managers, engineers, designers)
  console.log("Creating users...");
  const sampleUsers: InsertUser[] = [
    // Product managers
    { email: "sarah.chen@productco.com", name: "Sarah Chen", plan: "pro", status: "active" },
    { email: "mike.rodriguez@productco.com", name: "Mike Rodriguez", plan: "enterprise", status: "active" },
    { email: "emma.thompson@productco.com", name: "Emma Thompson", plan: "pro", status: "active" },
    
    // Engineers
    { email: "david.kim@productco.com", name: "David Kim", plan: "pro", status: "active" },
    { email: "alex.petrov@productco.com", name: "Alex Petrov", plan: "enterprise", status: "active" },
    { email: "lisa.wong@productco.com", name: "Lisa Wong", plan: "free", status: "active" },
    { email: "james.miller@productco.com", name: "James Miller", plan: "pro", status: "active" },
    { email: "maria.garcia@productco.com", name: "Maria Garcia", plan: "enterprise", status: "active" },
    
    // Designers
    { email: "anna.nielsen@productco.com", name: "Anna Nielsen", plan: "pro", status: "active" },
    { email: "ryan.clark@productco.com", name: "Ryan Clark", plan: "pro", status: "active" },
    { email: "sofia.andreev@productco.com", name: "Sofia Andreev", plan: "free", status: "active" },
    
    // Additional diverse users
    { email: "john.doe@freelance.com", name: "John Doe", plan: "free", status: "active" },
    { email: "jane.smith@startup.io", name: "Jane Smith", plan: "pro", status: "churned" },
    { email: "robert.brown@bigcorp.com", name: "Robert Brown", plan: "enterprise", status: "inactive" },
    { email: "michelle.davis@agency.com", name: "Michelle Davis", plan: "pro", status: "active" },
    { email: "carlos.fernandez@tech.com", name: "Carlos Fernandez", plan: "free", status: "active" },
    { email: "priya.patel@consulting.com", name: "Priya Patel", plan: "enterprise", status: "active" },
    { email: "thomas.anderson@matrix.com", name: "Thomas Anderson", plan: "pro", status: "active" },
    { email: "karen.johnson@design.studio", name: "Karen Johnson", plan: "free", status: "churned" },
    { email: "ahmed.hassan@mobile.dev", name: "Ahmed Hassan", plan: "pro", status: "active" }
  ];

  const createdUsers = [];
  for (const user of sampleUsers) {
    const createdUser = await storage.createUser(user);
    createdUsers.push(createdUser);
  }
  
  // Step 2: Create comprehensive feature dataset
  console.log("Creating features...");
  const sampleFeatures: InsertFeature[] = [
    // Authentication & Access
    { name: "User Login", description: "User authentication system", category: "authentication" },
    { name: "Single Sign-On", description: "SSO integration with enterprise providers", category: "authentication" },
    { name: "Two-Factor Auth", description: "Enhanced security with 2FA", category: "authentication" },
    { name: "Password Reset", description: "Self-service password recovery", category: "authentication" },
    
    // Core Dashboard Features
    { name: "Main Dashboard", description: "Primary user dashboard with key metrics", category: "dashboard" },
    { name: "Customizable Widgets", description: "User-configurable dashboard widgets", category: "dashboard" },
    { name: "Data Export", description: "Export data in various formats", category: "dashboard" },
    { name: "Real-time Updates", description: "Live data synchronization", category: "dashboard" },
    
    // Analytics & Reporting
    { name: "Analytics Overview", description: "High-level analytics and insights", category: "analytics" },
    { name: "Custom Reports", description: "User-generated custom reports", category: "analytics" },
    { name: "A/B Testing", description: "Experiment tracking and analysis", category: "analytics" },
    { name: "Funnel Analysis", description: "User journey and conversion tracking", category: "analytics" },
    { name: "Cohort Analysis", description: "User retention and behavior analysis", category: "analytics" },
    
    // Collaboration Tools
    { name: "Team Sharing", description: "Share insights with team members", category: "collaboration" },
    { name: "Comments System", description: "Add comments to reports and dashboards", category: "collaboration" },
    { name: "Notifications", description: "Alert system for important events", category: "collaboration" },
    { name: "Slack Integration", description: "Send reports to Slack channels", category: "collaboration" },
    
    // Data Management
    { name: "Data Sources", description: "Connect multiple data sources", category: "data" },
    { name: "Query Builder", description: "Visual SQL query construction", category: "data" },
    { name: "Data Validation", description: "Ensure data quality and consistency", category: "data" },
    { name: "Automated Backups", description: "Regular data backup and recovery", category: "data" },
    
    // User Management
    { name: "User Profiles", description: "Manage user accounts and preferences", category: "user-management" },
    { name: "Role Management", description: "Define user roles and permissions", category: "user-management" },
    { name: "API Access", description: "Programmatic access to platform features", category: "user-management" },
    
    // Advanced Features
    { name: "Machine Learning Insights", description: "AI-powered data insights", category: "advanced" },
    { name: "Predictive Analytics", description: "Forecast future trends", category: "advanced" },
    { name: "Custom Integrations", description: "Build custom data connectors", category: "advanced" }
  ];

  const createdFeatures = [];
  for (const feature of sampleFeatures) {
    const createdFeature = await storage.createFeature(feature);
    createdFeatures.push(createdFeature);
  }
  
  // Step 3: Generate user-feature engagement data with realistic adoption patterns
  console.log("Creating user-feature engagement data...");
  
  // Create realistic feature adoption patterns
  const coreFeatures = createdFeatures.filter(f => 
    ["authentication", "dashboard"].includes(f.category)
  );
  const advancedFeatures = createdFeatures.filter(f => 
    ["analytics", "advanced"].includes(f.category)
  );
  const collaborationFeatures = createdFeatures.filter(f => 
    f.category === "collaboration"
  );
  
  for (const user of createdUsers) {
    // All active users use core features
    if (user.status === "active") {
      for (const feature of coreFeatures) {
        const firstUsed = getRandomDate(new Date(2024, 0, 1), new Date(2024, 8, 1));
        const lastUsed = getRandomDate(firstUsed, new Date(2024, 8, 18));
        const usageCount = getRandomInt(5, 150);
        
        await storage.createUserFeature({
          userId: user.id,
          featureId: feature.id,
          usageCount
        });
      }
      
      // Pro and enterprise users more likely to use advanced features
      if (["pro", "enterprise"].includes(user.plan)) {
        const featuresToUse = advancedFeatures.slice(0, getRandomInt(2, advancedFeatures.length));
        for (const feature of featuresToUse) {
          const usageCount = getRandomInt(1, 50);
          await storage.createUserFeature({
            userId: user.id,
            featureId: feature.id,
            usageCount
          });
        }
      }
      
      // Random collaboration feature usage
      if (Math.random() > 0.3) { // 70% of users use collaboration features
        const featuresToUse = collaborationFeatures.slice(0, getRandomInt(1, 3));
        for (const feature of featuresToUse) {
          const usageCount = getRandomInt(1, 25);
          await storage.createUserFeature({
            userId: user.id,
            featureId: feature.id,
            usageCount
          });
        }
      }
    }
  }
  
  // Step 4: Generate user metrics over time
  console.log("Creating user metrics data...");
  
  const startDate = new Date(2024, 0, 1); // January 1, 2024
  const endDate = new Date(2024, 8, 18); // September 18, 2024
  
  for (const user of createdUsers.filter(u => u.status === "active")) {
    // Generate weekly metrics for each active user
    const currentDate = new Date(startDate);
    while (currentDate <= endDate) {
      // Create realistic engagement patterns
      let baseEngagement = 5.0;
      if (user.plan === "enterprise") baseEngagement = 8.0;
      else if (user.plan === "pro") baseEngagement = 6.5;
      
      // Add some randomness and trends
      const engagement = Math.max(1.0, Math.min(10.0, 
        baseEngagement + (Math.random() - 0.5) * 3.0
      ));
      
      const sessionDuration = getRandomInt(10, 180); // 10-180 minutes
      const actionsCount = getRandomInt(5, 100);
      
      await storage.createUserMetric({
        userId: user.id,
        date: new Date(currentDate),
        engagementScore: engagement.toFixed(1),
        sessionDuration,
        actionsCount
      });
      
      // Move to next week
      currentDate.setDate(currentDate.getDate() + 7);
    }
  }
  
  // Step 5: Generate realistic user interaction events
  console.log("Creating user interaction events...");
  
  const eventTypes = [
    "page_view", "button_click", "form_submit", "search", "export", 
    "share", "comment", "login", "logout", "feature_discovery",
    "report_generated", "dashboard_customized", "integration_connected"
  ];
  
  // Generate events over the past 3 months
  const eventStartDate = new Date(2024, 5, 1); // June 1, 2024
  
  for (let i = 0; i < 2000; i++) { // Generate 2000 events
    const user = getRandomItem(createdUsers.filter(u => u.status === "active"));
    const eventType = getRandomItem(eventTypes);
    const timestamp = getRandomDate(eventStartDate, new Date());
    
    // Some events are associated with features, others are general
    let featureId = null;
    if (Math.random() > 0.3) { // 70% of events are feature-related
      const feature = getRandomItem(createdFeatures);
      featureId = feature.id;
    }
    
    // Generate relevant event data based on event type
    let eventData = {};
    switch (eventType) {
      case "page_view":
        eventData = { page: getRandomItem(["/dashboard", "/analytics", "/reports", "/settings", "/profile"]) };
        break;
      case "button_click":
        eventData = { button: getRandomItem(["export", "share", "save", "delete", "edit"]) };
        break;
      case "search":
        eventData = { query: getRandomItem(["user engagement", "conversion rate", "monthly active users", "retention"]) };
        break;
      case "export":
        eventData = { format: getRandomItem(["csv", "pdf", "xlsx"]), records: getRandomInt(100, 10000) };
        break;
      case "report_generated":
        eventData = { type: getRandomItem(["funnel", "cohort", "engagement", "custom"]), duration_ms: getRandomInt(500, 5000) };
        break;
      default:
        eventData = { source: "web_app" };
    }
    
    await storage.createEvent({
      userId: user.id,
      featureId,
      eventType,
      eventData,
    });
  }
  
  // Step 6: Create smart query templates for common analytics scenarios
  console.log("Creating query templates...");
  
  const queryTemplates: InsertQueryTemplate[] = [
    // User Retention Templates
    {
      name: "7-Day User Retention",
      description: "Calculate the percentage of users who return within 7 days of signup",
      category: "retention",
      question: "What is our 7-day user retention rate?",
      sqlTemplate: `
        WITH signup_cohorts AS (
          SELECT 
            DATE_TRUNC('week', signup_date) as cohort_week,
            COUNT(*) as total_signups
          FROM users 
          WHERE signup_date >= '{start_date}' AND signup_date <= '{end_date}'
          GROUP BY DATE_TRUNC('week', signup_date)
        ),
        retained_users AS (
          SELECT 
            DATE_TRUNC('week', u.signup_date) as cohort_week,
            COUNT(DISTINCT um.user_id) as retained_count
          FROM users u
          JOIN user_metrics um ON u.id = um.user_id
          WHERE u.signup_date >= '{start_date}' AND u.signup_date <= '{end_date}'
            AND um.date BETWEEN u.signup_date AND u.signup_date + INTERVAL '7 days'
          GROUP BY DATE_TRUNC('week', u.signup_date)
        )
        SELECT 
          s.cohort_week,
          s.total_signups,
          COALESCE(r.retained_count, 0) as retained_users,
          ROUND((COALESCE(r.retained_count, 0)::numeric / s.total_signups) * 100, 2) as retention_rate
        FROM signup_cohorts s
        LEFT JOIN retained_users r ON s.cohort_week = r.cohort_week
        ORDER BY s.cohort_week DESC;
      `,
      parameters: JSON.stringify({
        start_date: { type: "date", default: "30 days ago", description: "Start date for analysis" },
        end_date: { type: "date", default: "today", description: "End date for analysis" }
      })
    },
    
    // Feature Adoption Templates
    {
      name: "Feature Adoption Funnel",
      description: "Track how users progress through key features in their first 30 days",
      category: "adoption",
      question: "How do users adopt our key features in their first month?",
      sqlTemplate: `
        WITH user_cohorts AS (
          SELECT id, signup_date 
          FROM users 
          WHERE signup_date >= '{start_date}'
        ),
        feature_steps AS (
          SELECT 
            uc.id as user_id,
            uc.signup_date,
            f.name as feature_name,
            MIN(uf.first_used) as first_feature_use,
            CASE 
              WHEN MIN(uf.first_used) <= uc.signup_date + INTERVAL '30 days' THEN 1 
              ELSE 0 
            END as adopted_in_30days
          FROM user_cohorts uc
          LEFT JOIN user_features uf ON uc.id = uf.user_id
          LEFT JOIN features f ON uf.feature_id = f.id
          WHERE f.category IN ('authentication', 'dashboard', 'analytics')
          GROUP BY uc.id, uc.signup_date, f.name
        )
        SELECT 
          feature_name,
          COUNT(DISTINCT user_id) as total_users,
          SUM(adopted_in_30days) as adopted_users,
          ROUND((SUM(adopted_in_30days)::numeric / COUNT(DISTINCT user_id)) * 100, 2) as adoption_rate
        FROM feature_steps
        WHERE feature_name IS NOT NULL
        GROUP BY feature_name
        ORDER BY adoption_rate DESC;
      `,
      parameters: JSON.stringify({
        start_date: { type: "date", default: "90 days ago", description: "Cohort start date" }
      })
    },
    
    // Conversion Funnel Templates
    {
      name: "Plan Upgrade Conversion Funnel",
      description: "Analyze the conversion funnel from free to paid plans",
      category: "conversion",
      question: "What is our free to paid conversion rate and where do users drop off?",
      sqlTemplate: `
        WITH funnel_steps AS (
          SELECT 
            u.id,
            u.signup_date,
            u.plan,
            CASE WHEN uf_dashboard.user_id IS NOT NULL THEN 1 ELSE 0 END as used_dashboard,
            CASE WHEN uf_analytics.user_id IS NOT NULL THEN 1 ELSE 0 END as used_analytics,
            CASE WHEN uf_advanced.user_id IS NOT NULL THEN 1 ELSE 0 END as used_advanced,
            CASE WHEN u.plan != 'free' THEN 1 ELSE 0 END as converted_to_paid
          FROM users u
          LEFT JOIN (
            SELECT DISTINCT uf.user_id 
            FROM user_features uf 
            JOIN features f ON uf.feature_id = f.id 
            WHERE f.category = 'dashboard'
          ) uf_dashboard ON u.id = uf_dashboard.user_id
          LEFT JOIN (
            SELECT DISTINCT uf.user_id 
            FROM user_features uf 
            JOIN features f ON uf.feature_id = f.id 
            WHERE f.category = 'analytics'
          ) uf_analytics ON u.id = uf_analytics.user_id
          LEFT JOIN (
            SELECT DISTINCT uf.user_id 
            FROM user_features uf 
            JOIN features f ON uf.feature_id = f.id 
            WHERE f.category = 'advanced'
          ) uf_advanced ON u.id = uf_advanced.user_id
          WHERE u.signup_date >= '{start_date}'
        )
        SELECT 
          'Total Signups' as step,
          COUNT(*) as users,
          100.0 as conversion_rate
        FROM funnel_steps
        UNION ALL
        SELECT 
          'Used Dashboard' as step,
          SUM(used_dashboard) as users,
          ROUND((SUM(used_dashboard)::numeric / COUNT(*)) * 100, 2) as conversion_rate
        FROM funnel_steps
        UNION ALL
        SELECT 
          'Used Analytics' as step,
          SUM(used_analytics) as users,
          ROUND((SUM(used_analytics)::numeric / COUNT(*)) * 100, 2) as conversion_rate
        FROM funnel_steps
        UNION ALL
        SELECT 
          'Used Advanced Features' as step,
          SUM(used_advanced) as users,
          ROUND((SUM(used_advanced)::numeric / COUNT(*)) * 100, 2) as conversion_rate
        FROM funnel_steps
        UNION ALL
        SELECT 
          'Converted to Paid' as step,
          SUM(converted_to_paid) as users,
          ROUND((SUM(converted_to_paid)::numeric / COUNT(*)) * 100, 2) as conversion_rate
        FROM funnel_steps;
      `,
      parameters: JSON.stringify({
        start_date: { type: "date", default: "90 days ago", description: "Analysis period start" }
      })
    },
    
    // Cohort Analysis Templates
    {
      name: "Monthly Cohort Engagement Analysis",
      description: "Track how user engagement evolves over time by signup cohort",
      category: "cohort",
      question: "How does user engagement change over time for different signup cohorts?",
      sqlTemplate: `
        WITH cohorts AS (
          SELECT 
            id as user_id,
            DATE_TRUNC('month', signup_date) as cohort_month
          FROM users
          WHERE signup_date >= '{start_date}'
        ),
        cohort_metrics AS (
          SELECT 
            c.cohort_month,
            DATE_TRUNC('month', um.date) as metric_month,
            EXTRACT(month FROM AGE(um.date, c.cohort_month)) as months_since_signup,
            AVG(um.engagement_score) as avg_engagement,
            COUNT(DISTINCT c.user_id) as active_users
          FROM cohorts c
          JOIN user_metrics um ON c.user_id = um.user_id
          WHERE um.date >= c.cohort_month
          GROUP BY c.cohort_month, DATE_TRUNC('month', um.date)
        )
        SELECT 
          cohort_month,
          months_since_signup,
          active_users,
          ROUND(avg_engagement, 2) as average_engagement_score
        FROM cohort_metrics
        WHERE months_since_signup >= 0 AND months_since_signup <= 12
        ORDER BY cohort_month DESC, months_since_signup ASC;
      `,
      parameters: JSON.stringify({
        start_date: { type: "date", default: "12 months ago", description: "Cohort analysis start date" }
      })
    },
    
    // Growth Metrics Templates
    {
      name: "Weekly Active Users Growth",
      description: "Track weekly active user growth and engagement trends",
      category: "growth",
      question: "What is our weekly active user growth trend?",
      sqlTemplate: `
        WITH weekly_activity AS (
          SELECT 
            DATE_TRUNC('week', um.date) as week,
            COUNT(DISTINCT um.user_id) as weekly_active_users,
            AVG(um.engagement_score) as avg_engagement,
            SUM(um.actions_count) as total_actions
          FROM user_metrics um
          JOIN users u ON um.user_id = u.id
          WHERE um.date >= '{start_date}' AND u.status = 'active'
          GROUP BY DATE_TRUNC('week', um.date)
        ),
        growth_calc AS (
          SELECT 
            week,
            weekly_active_users,
            avg_engagement,
            total_actions,
            LAG(weekly_active_users) OVER (ORDER BY week) as prev_week_users
          FROM weekly_activity
        )
        SELECT 
          week,
          weekly_active_users,
          ROUND(avg_engagement, 2) as average_engagement,
          total_actions,
          CASE 
            WHEN prev_week_users IS NULL THEN NULL
            ELSE ROUND(((weekly_active_users - prev_week_users)::numeric / prev_week_users) * 100, 2)
          END as growth_rate_percent
        FROM growth_calc
        ORDER BY week DESC;
      `,
      parameters: JSON.stringify({
        start_date: { type: "date", default: "12 weeks ago", description: "Growth analysis period start" }
      })
    },
    
    // Power User Analysis
    {
      name: "Power User Identification",
      description: "Identify your most engaged and valuable users based on activity patterns",
      category: "engagement",
      question: "Who are our power users and what makes them different?",
      sqlTemplate: `
        WITH user_stats AS (
          SELECT 
            u.id,
            u.name,
            u.email,
            u.plan,
            u.signup_date,
            AVG(um.engagement_score) as avg_engagement,
            COUNT(DISTINCT uf.feature_id) as features_used,
            SUM(uf.usage_count) as total_feature_usage,
            COUNT(DISTINCT DATE_TRUNC('day', um.date)) as active_days
          FROM users u
          LEFT JOIN user_metrics um ON u.id = um.user_id
          LEFT JOIN user_features uf ON u.id = uf.user_id
          WHERE u.status = 'active' 
            AND um.date >= '{start_date}'
          GROUP BY u.id, u.name, u.email, u.plan, u.signup_date
        ),
        quartiles AS (
          SELECT 
            PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY avg_engagement) as engagement_q3,
            PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY features_used) as features_q3,
            PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY total_feature_usage) as usage_q3
          FROM user_stats
        )
        SELECT 
          us.name,
          us.email,
          us.plan,
          ROUND(us.avg_engagement, 2) as average_engagement,
          us.features_used,
          us.total_feature_usage,
          us.active_days,
          CASE 
            WHEN us.avg_engagement >= q.engagement_q3 
             AND us.features_used >= q.features_q3 
             AND us.total_feature_usage >= q.usage_q3 
            THEN 'Power User'
            ELSE 'Regular User'
          END as user_type
        FROM user_stats us
        CROSS JOIN quartiles q
        ORDER BY us.avg_engagement DESC, us.total_feature_usage DESC;
      `,
      parameters: JSON.stringify({
        start_date: { type: "date", default: "30 days ago", description: "Analysis period for power user identification" }
      })
    }
  ];

  for (const template of queryTemplates) {
    await storage.createQueryTemplate(template);
  }

  console.log("Database seeding completed successfully!");
  
  // Print summary statistics
  const stats = await storage.getDataSourceStats();
  const templates = await storage.getQueryTemplates();
  console.log("\nDatabase Summary:");
  console.log(`- Users: ${stats.usersCount}`);
  console.log(`- Features: ${stats.featuresCount}`);
  console.log(`- User Metrics: ${stats.userMetricsCount}`);
  console.log(`- Events: ${stats.eventsCount}`);
  console.log(`- Query Templates: ${templates.length}`);
  
  return stats;
}

// Run the seeding if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  seedDatabase()
    .then(() => {
      console.log("Seeding completed!");
      process.exit(0);
    })
    .catch((error) => {
      console.error("Seeding failed:", error);
      process.exit(1);
    });
}