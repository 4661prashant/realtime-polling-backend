import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { generateSQL } from "./services/openai";
import { insertQuerySchema, insertQueryTemplateSchema, insertSharedQuerySchema } from "@shared/schema";
import { z } from "zod";
import { randomBytes } from "crypto";

const generateSQLSchema = z.object({
  question: z.string().min(1, "Question is required"),
});

const executeQuerySchema = z.object({
  sqlQuery: z.string().min(1, "SQL query is required"),
  question: z.string().optional(),
});

const saveQuerySchema = z.object({
  id: z.string().min(1, "Query ID is required"),
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Generate SQL from natural language
  app.post("/api/queries/generate", async (req, res) => {
    try {
      const { question } = generateSQLSchema.parse(req.body);
      
      const result = await generateSQL(question);
      
      res.json({
        sql: result.sql,
        explanation: result.explanation,
        confidence: result.confidence,
      });
    } catch (error) {
      res.status(400).json({ 
        message: error instanceof Error ? error.message : "Failed to generate SQL query" 
      });
    }
  });

  // Execute SQL query
  app.post("/api/queries/execute", async (req, res) => {
    try {
      const { sqlQuery, question } = executeQuerySchema.parse(req.body);
      
      const startTime = Date.now();
      const results = await storage.executeRawQuery(sqlQuery);
      const executionTime = (Date.now() - startTime) / 1000;

      // Save the query to history
      if (question) {
        await storage.createQuery({
          question,
          sqlQuery,
          executionTime: executionTime.toString(),
          resultCount: results.length,
          isSaved: false,
        });
      }

      res.json({
        results,
        executionTime,
        resultCount: results.length,
      });
    } catch (error) {
      res.status(400).json({ 
        message: error instanceof Error ? error.message : "Failed to execute SQL query" 
      });
    }
  });

  // Get query history
  app.get("/api/queries/history", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const queries = await storage.getQueries(limit);
      res.json(queries);
    } catch (error) {
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to fetch query history" 
      });
    }
  });

  // Get saved queries
  app.get("/api/queries/saved", async (req, res) => {
    try {
      const queries = await storage.getSavedQueries();
      res.json(queries);
    } catch (error) {
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to fetch saved queries" 
      });
    }
  });

  // Save a query
  app.post("/api/queries/save", async (req, res) => {
    try {
      const { id } = saveQuerySchema.parse(req.body);
      const query = await storage.saveQuery(id);
      res.json(query);
    } catch (error) {
      res.status(400).json({ 
        message: error instanceof Error ? error.message : "Failed to save query" 
      });
    }
  });

  // Get data source statistics
  app.get("/api/data-sources", async (req, res) => {
    try {
      const stats = await storage.getDataSourceStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to fetch data source statistics" 
      });
    }
  });

  // Get all features
  app.get("/api/features", async (req, res) => {
    try {
      const features = await storage.getAllFeatures();
      res.json(features);
    } catch (error) {
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to fetch features" 
      });
    }
  });

  // Admin endpoint to seed the database
  app.post("/api/admin/seed", async (req, res) => {
    try {
      const { seedDatabase } = await import("./seed-data");
      console.log("Starting database seeding from admin endpoint...");
      
      const stats = await seedDatabase();
      
      res.json({
        success: true,
        message: "Database seeded successfully",
        stats
      });
    } catch (error) {
      console.error("Seeding error:", error);
      res.status(500).json({ 
        success: false,
        message: error instanceof Error ? error.message : "Failed to seed database" 
      });
    }
  });

  // Query Templates endpoints
  app.get("/api/query-templates", async (req, res) => {
    try {
      const { category } = req.query;
      const templates = await storage.getQueryTemplates(category as string);
      res.json(templates);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch query templates" });
    }
  });

  app.get("/api/query-templates/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const template = await storage.getQueryTemplate(id);
      if (!template) {
        return res.status(404).json({ message: "Template not found" });
      }
      res.json(template);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch query template" });
    }
  });

  app.post("/api/query-templates/:id/use", async (req, res) => {
    try {
      const { id } = req.params;
      const { parameters } = req.body;
      
      const template = await storage.getQueryTemplate(id);
      if (!template) {
        return res.status(404).json({ message: "Template not found" });
      }

      // Replace parameters in SQL template
      let sql = template.sqlTemplate;
      if (parameters) {
        Object.entries(parameters).forEach(([key, value]) => {
          sql = sql.replace(new RegExp(`\\{${key}\\}`, 'g'), value as string);
        });
      }

      // Increment usage count
      await storage.incrementTemplateUsage(id);
      
      res.json({
        question: template.question,
        sql: sql.trim(),
        explanation: template.description,
        templateName: template.name
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to use query template" });
    }
  });

  // Quick Insights endpoint
  app.get("/api/insights", async (req, res) => {
    try {
      const insights = await storage.getQuickInsights();
      res.json(insights);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch insights" });
    }
  });

  // Export functionality
  app.post("/api/queries/export", async (req, res) => {
    try {
      const { format, data, filename, queryInfo } = req.body;
      
      if (format === "csv") {
        if (!data || !Array.isArray(data) || data.length === 0) {
          return res.status(400).json({ message: "No data to export" });
        }

        const headers = Object.keys(data[0]);
        const csvContent = [
          headers.join(","),
          ...data.map(row => 
            headers.map(header => {
              const value = row[header];
              // Escape commas and quotes in CSV
              if (typeof value === 'string' && (value.includes(',') || value.includes('"'))) {
                return `"${value.replace(/"/g, '""')}"`;
              }
              return value || '';
            }).join(",")
          )
        ].join("\n");

        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', `attachment; filename="${filename || 'export'}.csv"`);
        res.send(csvContent);
      } else {
        res.status(400).json({ message: "Unsupported export format" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to export data" });
    }
  });

  // Shared queries
  app.post("/api/queries/:id/share", async (req, res) => {
    try {
      const { id } = req.params;
      const { isPublic, expiresIn } = req.body;
      
      const shareToken = randomBytes(32).toString('hex');
      let expiresAt = null;
      
      if (expiresIn) {
        expiresAt = new Date();
        expiresAt.setHours(expiresAt.getHours() + parseInt(expiresIn));
      }

      const sharedQuery = await storage.createSharedQuery({
        queryId: id,
        shareToken,
        isPublic: isPublic || false,
        expiresAt
      });

      res.json({
        shareToken,
        shareUrl: `${req.protocol}://${req.get('host')}/shared/${shareToken}`,
        expiresAt
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to create shared query" });
    }
  });

  app.get("/api/shared/:token", async (req, res) => {
    try {
      const { token } = req.params;
      const sharedQuery = await storage.getSharedQuery(token);
      
      if (!sharedQuery) {
        return res.status(404).json({ message: "Shared query not found" });
      }

      if (sharedQuery.expiresAt && new Date() > sharedQuery.expiresAt) {
        return res.status(410).json({ message: "Shared query has expired" });
      }

      // Get the original query
      const queries = await storage.getQueries(1000);
      const originalQuery = queries.find(q => q.id === sharedQuery.queryId);
      
      if (!originalQuery) {
        return res.status(404).json({ message: "Original query not found" });
      }

      res.json({
        question: originalQuery.question,
        sql: originalQuery.sqlQuery,
        isPublic: sharedQuery.isPublic,
        createdAt: originalQuery.createdAt
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch shared query" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
