import OpenAI from "openai";

const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export interface SQLGenerationResult {
  sql: string;
  explanation: string;
  confidence: number;
}

export async function generateSQL(naturalLanguageQuery: string): Promise<SQLGenerationResult> {
  try {
    const systemPrompt = `You are an expert SQL developer specializing in product analytics. Convert natural language questions into SQL queries for a PostgreSQL database.

Database schema:
- users (id, email, name, signup_date, plan, status)
- features (id, name, description, category, is_active, created_at)
- user_features (id, user_id, feature_id, first_used, last_used, usage_count)
- user_metrics (id, user_id, date, engagement_score, session_duration, actions_count)
- events (id, user_id, feature_id, event_type, event_data, timestamp)

Return your response as JSON with:
{
  "sql": "the complete SQL query",
  "explanation": "brief explanation of what the query does",
  "confidence": number between 0 and 1
}

Guidelines:
- Use proper PostgreSQL syntax
- Include appropriate JOINs when referencing multiple tables
- Use meaningful aliases for tables
- Add LIMIT clauses for large result sets
- Format the SQL with proper indentation
- Consider performance implications`;

    const response = await openai.chat.completions.create({
      model: "gpt-5", // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: systemPrompt,
        },
        {
          role: "user",
          content: naturalLanguageQuery,
        },
      ],
      response_format: { type: "json_object" },
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error('No content received from OpenAI');
    }
    const result = JSON.parse(content);

    return {
      sql: result.sql,
      explanation: result.explanation,
      confidence: Math.max(0, Math.min(1, result.confidence)),
    };
  } catch (error) {
    throw new Error(`Failed to generate SQL: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}
